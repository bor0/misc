﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule
{
    public partial class MainForm : Form
    {
        public bool closeButton = false;
        public MainForm()
        {
            InitializeComponent();
        }

        public void ShowLoginForm()
        {
            loginForm1.Visible = true;
            loginForm1.Left = (this.ClientSize.Width - loginForm1.Width) / 2;
            loginForm1.Top = (this.ClientSize.Height - loginForm1.Height) / 2;
            AcceptButton = (Button)loginForm1.Controls["button1"];
            loginForm1.Controls["tb_username"].Focus();
        }

        public void ShowUserForm()
        {
            userForm1.Visible = true;
            userForm1.Left = (this.ClientSize.Width - userForm1.Width) / 2;
            userForm1.Top = (this.ClientSize.Height - userForm1.Height) / 2;
            userForm1.LoadVisibility();
            AcceptButton = null;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

            Common.MainForm = this;

            int LicenseStatus = LicenseModule.CheckLicense();
            this.Text = Common.GetCaption();

            if (LicenseStatus != 1)
            {
                licenseForm1.Visible = true;
                licenseForm1.Left = (this.ClientSize.Width - licenseForm1.Width) / 2;
                licenseForm1.Top = (this.ClientSize.Height - licenseForm1.Height) / 2;
                licenseForm1.Controls["tb_ime_registrant"].Focus();
                AcceptButton = (Button)licenseForm1.Controls["button1"];
                return;
            }

            ShowLoginForm();

        }

        private void userForm1_VisibleChanged(object sender, EventArgs e)
        {
            userForm1.LoadVisibility();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!closeButton) e.Cancel = true;
        }

    }
}

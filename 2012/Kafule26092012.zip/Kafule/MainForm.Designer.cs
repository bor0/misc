﻿namespace Kafule
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userForm1 = new Kafule.User_Controls.UserForm();
            this.loginForm1 = new Kafule.User_Controls.LoginForm();
            this.licenseForm1 = new Kafule.LicenseForm();
            this.SuspendLayout();
            // 
            // userForm1
            // 
            this.userForm1.BackColor = System.Drawing.SystemColors.Control;
            this.userForm1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.userForm1.Location = new System.Drawing.Point(13, 13);
            this.userForm1.Name = "userForm1";
            this.userForm1.Size = new System.Drawing.Size(1024, 768);
            this.userForm1.TabIndex = 2;
            this.userForm1.Visible = false;
            // 
            // loginForm1
            // 
            this.loginForm1.Location = new System.Drawing.Point(12, 12);
            this.loginForm1.Name = "loginForm1";
            this.loginForm1.Size = new System.Drawing.Size(288, 113);
            this.loginForm1.TabIndex = 1;
            this.loginForm1.Visible = false;
            // 
            // licenseForm1
            // 
            this.licenseForm1.Location = new System.Drawing.Point(12, 12);
            this.licenseForm1.Name = "licenseForm1";
            this.licenseForm1.Size = new System.Drawing.Size(293, 142);
            this.licenseForm1.TabIndex = 0;
            this.licenseForm1.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 353);
            this.Controls.Add(this.userForm1);
            this.Controls.Add(this.loginForm1);
            this.Controls.Add(this.licenseForm1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главна Форма";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private LicenseForm licenseForm1;
        private User_Controls.LoginForm loginForm1;
        private User_Controls.UserForm userForm1;

    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule.User_Controls
{
    public partial class IzdadiSmetkaForm : UserControl
    {

        IList<BillProduct> products = new List<BillProduct>();

        public IzdadiSmetkaForm()
        {
            InitializeComponent();
        }

        public void ClearFields()
        {
            listBox1.DataSource = null;
            comboBox1.Items.Clear();
            numericUpDown1.Value = 1;
            numericUpDown2.Value = 1;
            label4.Text = "";
            products.Clear();
        }

        public void LoadData()
        {
            ClearFields();
            foreach (var li in Products.GetProducts())
            {
                comboBox1.Items.Add(li);
            }
            Common.MainForm.AcceptButton = button1;
            Common.MainForm.CancelButton = button3;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Parent.Controls["izdadiSmetkaForm1"].Visible = false;
            ClearFields();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (products.Count == 0)
            {
                MessageBox.Show("Ве молиме внесете продукти!", Common.GetCaption());
                return;
            }

            if (FiscalCash.isPrinterSet())
            {

                bool fiscal = true;

                if (Common.user_status == 1)
                {
                    if (MessageBox.Show("Дали сакате да извадите фискална сметка?", Common.GetCaption(), MessageBoxButtons.YesNo) == DialogResult.No)
                    {
                        fiscal = false;
                    }
                }

                if (fiscal)
                {

                    FiscalCash x = new FiscalCash();
                    x.InitInterface();
                    string output = "";
                    foreach (var li in products)
                    {
                        x.AddProduct(li.name, li.price.ToString(), li.quantity.ToString());
                    }
                    byte[] p = x.IssueBill();
                    for (int i = 0; i < p.Length; i++) output += (char)p[i];
                    if (output.Contains("ERROR"))
                    {
                        MessageBox.Show("Се случи грешка при комуникација со Фискалната каса.\n" + output, "Грешка");
                        return;
                    }
                }
            }

            if (Bills.IssueBill(products, (int)numericUpDown2.Value))
            {
                MessageBox.Show("Успешно издавање на сметка!", Common.GetCaption());
                ClearFields();
            }
            else
            {
                MessageBox.Show("Се случи грешка при издавање на сметка!", Common.GetCaption());
            }
        }

        private void PopulateListboxAndPrice()
        {
            listBox1.DataSource = null;
            int total_sum = 0;
            IList<Bills.ListBoxValues> lbv = new List<Bills.ListBoxValues>();
            foreach (var li in products)
            {
                Bills.ListBoxValues tmp = new Bills.ListBoxValues();
                string product_name_quantity = li.quantity + " " + li.name;

                tmp.ID = li.id;
                tmp.Value = product_name_quantity;
                lbv.Add(tmp);

                total_sum += li.price * li.quantity;
            }
            listBox1.DisplayMember = "Value";
            listBox1.ValueMember = "ID";
            listBox1.DataSource = lbv;
            label4.Text = total_sum.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Ве молиме одберете продукт од листата!", Common.GetCaption());
                return;
            }
            BillProduct bp = new BillProduct();
            bp.id = int.Parse(((Product)comboBox1.SelectedItem).id.ToString());

            var prod = products.Where(p => p.id == bp.id);

            if (prod.Count() != 0) products.Remove(prod.Single());
            
            bp.quantity = (int)numericUpDown1.Value;
            bp.name = ((Product)comboBox1.SelectedItem).name;
            bp.price = ((Product)comboBox1.SelectedItem).price;
            products.Add(bp);
            PopulateListboxAndPrice();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Ве молиме одберете продукт!", Common.GetCaption());
                return;
            }
            int selected_id = ((Bills.ListBoxValues)listBox1.SelectedItem).ID;
            var prod = products.Where(p => p.id == selected_id);
            if (prod.Count() != 0)
            {
                products.Remove(prod.Single());
            }
            PopulateListboxAndPrice();
        }

    }
}

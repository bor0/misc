﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule.User_Controls
{
    public partial class ManageUsersForm : UserControl
    {
        private IList<User> users;
        private int current_id = 0;

        public ManageUsersForm()
        {
            InitializeComponent();
        }

        public void ClearFields()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void ClearListboxSelection()
        {
            listBox1.SelectedIndexChanged -= listBox1_SelectedIndexChanged;
            listBox1.SelectedIndex = -1;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
        }

        public void LoadData()
        {
            listBox1.SelectedIndexChanged -= listBox1_SelectedIndexChanged;
            listBox1.DataSource = users = ManageUsers.GetUsers();
            listBox1.DisplayMember = "login_name";
            listBox1.ValueMember = "id";
            ClearListboxSelection();
            ClearFields();
            Common.MainForm.AcceptButton = button2;
            Common.MainForm.CancelButton = button3;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedValue == null) return;
            button4.Enabled = true;
            foreach (var li in users)
            {
                if (li.id == int.Parse(listBox1.SelectedValue.ToString()))
                {
                    current_id = li.id;
                    textBox1.Text = li.login_name;
                    textBox2.Text = li.first_name;
                    textBox3.Text = li.last_name;
                    textBox4.Text = li.embg;
                    textBox6.Text = li.phone;
                    break;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button4.Enabled = false;
            current_id = 0;
            ClearListboxSelection();
            ClearFields();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Parent.Controls["manageUsersForm1"].Visible = false;
            ClearFields();
            listBox1.SelectedIndexChanged -= listBox1_SelectedIndexChanged;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox4.Text.Trim() == "" || textBox5.Text.Trim() == "" || textBox6.Text.Trim() == "")
            {
                MessageBox.Show("Ве молиме внесете ги сите полиња!", Common.GetCaption());
                return;
            }
            bool result;
            if (current_id == 0)
            {
                result = ManageUsers.AddUser(textBox2.Text.Trim(), textBox3.Text.Trim(), textBox1.Text.Trim(), textBox4.Text.Trim(), textBox6.Text.Trim(), textBox5.Text.Trim());
            }
            else
            {
                result = ManageUsers.ModifyUser(current_id, textBox2.Text.Trim(), textBox3.Text.Trim(), textBox1.Text.Trim(), textBox4.Text.Trim(), textBox6.Text.Trim(), textBox5.Text.Trim());
            }
            if (result)
            {
                ClearFields();
                LoadData();
                current_id = 0;
                MessageBox.Show("Успешно е ажуриран корисникот!", Common.GetCaption());
            }
            else
            {
                MessageBox.Show("Се случи грешка при ажурирање на корисникот!", Common.GetCaption());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (current_id == 0)
            {
                MessageBox.Show("Ве молиме одберете корисник за да избришете!", Common.GetCaption());
            }
            else
            {
                ManageUsers.DeleteUser(current_id);
                ClearFields();
                LoadData();
                current_id = 0;
                button4.Enabled = false;
                MessageBox.Show("Успешно е избришан корисникот!", Common.GetCaption());
            }
        }
    }
}

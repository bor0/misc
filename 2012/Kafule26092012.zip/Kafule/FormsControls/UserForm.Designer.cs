﻿namespace Kafule.User_Controls
{
    partial class UserForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserForm));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.izdadiSmetkaForm1 = new Kafule.User_Controls.IzdadiSmetkaForm();
            this.prometForm1 = new Kafule.User_Controls.PrometForm();
            this.manageUsersForm1 = new Kafule.User_Controls.ManageUsersForm();
            this.productsForm1 = new Kafule.User_Controls.ProductsForm();
            this.reservationForm1 = new Kafule.User_Controls.ReservationForm();
            this.label2 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(131, 245);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 39);
            this.button1.TabIndex = 0;
            this.button1.Text = "АЖУРИРАЊЕ НА КОРИСНИЦИ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(131, 290);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(151, 39);
            this.button2.TabIndex = 1;
            this.button2.Text = "ИЗВЕШТАИ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(131, 335);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 39);
            this.button3.TabIndex = 2;
            this.button3.Text = "РЕЗЕРВАЦИИ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(131, 380);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(151, 39);
            this.button4.TabIndex = 3;
            this.button4.Text = "ПРОДУКТИ НА ЗАЛИХА И ЦЕНИ";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(131, 470);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(151, 39);
            this.button5.TabIndex = 5;
            this.button5.Text = "ПРОМЕТ ВО ПЕРИОД";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(131, 605);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(151, 39);
            this.button6.TabIndex = 8;
            this.button6.Text = "ОДЈАВА";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(131, 650);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(151, 39);
            this.button7.TabIndex = 9;
            this.button7.Text = "ИЗЛЕЗ";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(131, 425);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(151, 39);
            this.button8.TabIndex = 4;
            this.button8.Text = "ИЗДАВАЊЕ СМЕТКА";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(98, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(797, 226);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(750, 689);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 26);
            this.label1.TabIndex = 13;
            this.label1.Text = "label1";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // izdadiSmetkaForm1
            // 
            this.izdadiSmetkaForm1.Location = new System.Drawing.Point(309, 246);
            this.izdadiSmetkaForm1.Name = "izdadiSmetkaForm1";
            this.izdadiSmetkaForm1.Size = new System.Drawing.Size(554, 371);
            this.izdadiSmetkaForm1.TabIndex = 12;
            this.izdadiSmetkaForm1.Visible = false;
            // 
            // prometForm1
            // 
            this.prometForm1.Location = new System.Drawing.Point(309, 245);
            this.prometForm1.Name = "prometForm1";
            this.prometForm1.Size = new System.Drawing.Size(602, 371);
            this.prometForm1.TabIndex = 10;
            this.prometForm1.Visible = false;
            // 
            // manageUsersForm1
            // 
            this.manageUsersForm1.Location = new System.Drawing.Point(309, 245);
            this.manageUsersForm1.Name = "manageUsersForm1";
            this.manageUsersForm1.Size = new System.Drawing.Size(602, 371);
            this.manageUsersForm1.TabIndex = 9;
            this.manageUsersForm1.Visible = false;
            // 
            // productsForm1
            // 
            this.productsForm1.Location = new System.Drawing.Point(309, 245);
            this.productsForm1.Name = "productsForm1";
            this.productsForm1.Size = new System.Drawing.Size(602, 371);
            this.productsForm1.TabIndex = 8;
            this.productsForm1.Visible = false;
            // 
            // reservationForm1
            // 
            this.reservationForm1.Location = new System.Drawing.Point(309, 246);
            this.reservationForm1.Name = "reservationForm1";
            this.reservationForm1.Size = new System.Drawing.Size(554, 371);
            this.reservationForm1.TabIndex = 14;
            this.reservationForm1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label2.Location = new System.Drawing.Point(23, 736);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "http://bor0.users.sf.net/kafule/";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(131, 515);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(151, 39);
            this.button9.TabIndex = 6;
            this.button9.Text = "ДНЕВЕН ФИНАНСИСКИ ИЗВЕШТАЈ";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(131, 560);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(151, 39);
            this.button10.TabIndex = 7;
            this.button10.Text = "ДАТУМ И ВРЕМЕ НА ФИСКАЛЕН ПРИНТЕР";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // UserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.reservationForm1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.izdadiSmetkaForm1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.prometForm1);
            this.Controls.Add(this.manageUsersForm1);
            this.Controls.Add(this.productsForm1);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "UserForm";
            this.Size = new System.Drawing.Size(1022, 766);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private ProductsForm productsForm1;
        private ManageUsersForm manageUsersForm1;
        private PrometForm prometForm1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private IzdadiSmetkaForm izdadiSmetkaForm1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private ReservationForm reservationForm1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;

    }
}

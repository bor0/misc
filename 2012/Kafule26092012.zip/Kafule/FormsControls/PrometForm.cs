﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule.User_Controls
{
    public partial class PrometForm : UserControl
    {

        public PrometForm()
        {
            InitializeComponent();
        }

        public void ClearFields()
        {
            label4.Text = "";
            dataGridView1.Rows.Clear();
        }

        public void LoadData()
        {
            ClearFields();
            Common.MainForm.AcceptButton = button1;
            Common.MainForm.CancelButton = button3;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Parent.Controls["prometForm1"].Visible = false;
            ClearFields();
        }

        public void button1_Click(object sender, EventArgs e)
        {

            button1.Enabled = false;
            ClearFields();
            int total_sum = 0;
            bool trigger = false;
            foreach (var li in Bills.GetBills(Common.ParseStartDate(dateTimePicker1.Value), Common.ParseEndDate(dateTimePicker2.Value)))
            {
                trigger = true;
                string val1 = li.id.ToString();
                string val2 = li.bill_table.ToString();
                int sum = 0;
                foreach (var li2 in Bills.GetBillDetails(li.id))
                {
                    sum += li2.price * li2.quantity;
                }
                total_sum += sum;
                string val3 = sum.ToString();
                IList<User> user = ManageUsers.GetUserById(li.billed_by);
                string full_name = "Вработен";
                if (user.Count != 0) full_name = user[0].first_name + " " + user[0].last_name;
                string val4 = full_name;
                string val5 = li.bill_date.ToShortDateString();
                string val6 = (li.bill_fiscal) ? "Да" : "Не";
                dataGridView1.Rows.Add(new object[]{val1, val2, val3, val4, val5, val6});
            }
            if (trigger) label4.Text = total_sum.ToString();
            button1.Enabled = true;
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                int id = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                StringBuilder sb = new StringBuilder();
                foreach (var li in Bills.GetBillDetails(id))
                {
                    sb.Append(li.quantity + " " + li.product_name + " = " + (li.quantity * li.price) + "\n");
                }
                MessageBox.Show(sb.ToString(), Common.GetCaption());
            }
            catch (Exception)
            {
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                bool fiscal = (dataGridView1.CurrentRow.Cells[5].Value.ToString() == "Да") ? true : false;
                if (FiscalCash.isPrinterSet() && fiscal)
                {
                    IList<BillDetail> bd = Bills.GetBillDetails(id);
                    FiscalCash x = new FiscalCash();
                    x.InitInterface();
                    string output = "";
                    foreach (var li in bd)
                    {
                        x.AddProductStorno(li.product_name, li.price.ToString(), li.quantity.ToString());
                    }
                    byte[] p = x.IssueStorno();
                    for (int i = 0; i < p.Length; i++) output += (char)p[i];
                    if (output.Contains("ERROR"))
                    {
                        MessageBox.Show("Се случи грешка при комуникација со Фискалната каса.\n" + output, "Грешка");
                        return;
                    }
                }

                bool res = Bills.DeleteBill(id);
                if (res)
                {
                    MessageBox.Show("Успешно бришење на сметка!", Common.GetCaption());

                }
                else
                {
                    MessageBox.Show("Се случи грешка при бришење на сметка!", Common.GetCaption());
                }
            }
            catch (Exception)
            {
            }
        }

    }
}

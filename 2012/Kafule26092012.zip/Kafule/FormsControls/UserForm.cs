﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;
using Kafule.FormsControls;

namespace Kafule.User_Controls
{
    public partial class UserForm : UserControl
    {
        public UserForm()
        {
            InitializeComponent();
        }

        public void ClearControlsVisibility()
        {
            Common.MainForm.AcceptButton = null;
            Common.MainForm.CancelButton = null;
            productsForm1.Visible = false;
            productsForm1.ClearFields();
            manageUsersForm1.Visible = false;
            manageUsersForm1.ClearFields();
            prometForm1.Visible = false;
            prometForm1.ClearFields();
            izdadiSmetkaForm1.Visible = false;
            izdadiSmetkaForm1.ClearFields();
            reservationForm1.Visible = false;
            reservationForm1.ClearFields();
        }

        public void LoadVisibility()
        {
            if (Common.user_status == 1)
            {
                button1.Visible = true;
                button2.Visible = true;
                button4.Visible = true;
                button5.Visible = true;
                button7.Visible = true;
                button9.Visible = true;
                button10.Visible = true;
                StringBuilder sb = new StringBuilder();

                foreach (var li in Products.GetProducts())
                {
                    if (li.stock < 15)
                    {
                        sb.Append(li.name + " (" + li.stock + ")" + "\n");
                    }
                }

                if (sb.Length != 0)
                {
                    MessageBox.Show("Недостасуваат или премногу мал број\nна залиха на следните продукти:\n\n" + sb.ToString(), Common.GetCaption());
                }

            }
            else
            {
                button1.Visible = false;
                button2.Visible = false;
                button4.Visible = false;
                button5.Visible = false;
                button7.Visible = false;
                button9.Visible = false;
                button10.Visible = false;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Parent.Controls["userForm1"].Visible = false;
            ClearControlsVisibility();
            ((MainForm)Parent).ShowLoginForm();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ((MainForm)Parent).closeButton = true;
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClearControlsVisibility();
            manageUsersForm1.LoadData();
            manageUsersForm1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClearControlsVisibility();
            productsForm1.LoadData();
            productsForm1.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClearControlsVisibility();
            prometForm1.LoadData();
            prometForm1.Visible = true;
            prometForm1.button1_Click(null, null);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ClearControlsVisibility();
            izdadiSmetkaForm1.LoadData();
            izdadiSmetkaForm1.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ова е имплементирано само во напредната верзија на Кафуле!", Common.GetCaption());
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ClearControlsVisibility();
            reservationForm1.LoadData();
            reservationForm1.Visible = true;
            reservationForm1.button1_Click(null, null);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://bor0.users.sf.net/kafule/");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (FiscalCash.isPrinterSet() == false)
            {
                MessageBox.Show("Не е наместен фискален принтер!", Common.GetCaption());
            }
            else
            {
                if (MessageBox.Show("Дали сте сигурни дека сакате да извадите дневен финансиски извештај?", Common.GetCaption(), MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    string output = "";
                    FiscalCash x = new FiscalCash();
                    x.InitInterface();
                    byte[] p = x.DailyFiscalClose();
                    for (int i = 0; i < p.Length; i++) output += (char)p[i];
                    if (output.Contains("ERROR")) MessageBox.Show("Се случи грешка при комуникација со Фискалната каса.\n" + output, "Грешка");
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (FiscalCash.isPrinterSet() == false)
            {
                MessageBox.Show("Не е наместен фискален принтер!", Common.GetCaption());
            }
            else
            {
                ManageFiscalTime mft = new ManageFiscalTime();
                mft.ShowDialog();
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            using (Font myFont = new Font("Arial", 51, FontStyle.Italic))
            {
                e.Graphics.DrawString(LicenseModule.LicenseName, myFont, Brushes.Green, new Point(348, 127));
            }
        }
    }
}

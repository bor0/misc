﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule.FormsControls
{
    public partial class ManageReservation : Form
    {

        public int reservation_id;

        public ManageReservation(int reservation_id = 0)
        {
            this.reservation_id = reservation_id;
            InitializeComponent();
        }

        private void ManageReservation_Load(object sender, EventArgs e)
        {
            if (reservation_id != 0)
            {
                button1.Visible = true;
                foreach (var li in Reservations.GetReservationsById(reservation_id))
                {
                    textBox2.Text = li.reservation_name;
                    numericUpDown1.Value = li.reservation_table;
                    dateTimePicker1.Value = li.reservation_date;
                }
            }
            this.Text = Common.GetCaption();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Reservations.DeleteReservation(reservation_id))
            {
                MessageBox.Show("Успешно е избришана регистрацијата!", Common.GetCaption());
                this.Close();
            }
            else
            {
                MessageBox.Show("Се случи грешка при бришење на регистрацијата!", Common.GetCaption());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text.Trim() == "")
            {
                MessageBox.Show("Ве молиме внесете име на резервација!", Common.GetCaption());
                return;
            }
            bool res;
            if (reservation_id == 0)
            {
                res = Reservations.AddReservation(textBox2.Text.Trim(), (int)numericUpDown1.Value, dateTimePicker1.Value);
            }
            else
            {
                res = Reservations.ModifyReservation(reservation_id, textBox2.Text.Trim(), (int)numericUpDown1.Value, dateTimePicker1.Value);
            }
            if (res == true)
            {
                MessageBox.Show("Успешно е ажурирана резервацијата!", Common.GetCaption());
                this.Close();
            }
            else
            {
                MessageBox.Show("Се случи грешка при ажурирање на резервацијата!", Common.GetCaption());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule.User_Controls
{
    public partial class ProductsForm : UserControl
    {
        private IList<Product> products;
        private int current_id = 0;

        public ProductsForm()
        {
            InitializeComponent();
        }

        public void ClearFields()
        {
            textBox1.Text = "";
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
        }

        private void ClearListboxSelection()
        {
            listBox1.SelectedIndexChanged -= listBox1_SelectedIndexChanged;
            listBox1.SelectedIndex = -1;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
        }

        public void LoadData()
        {
            listBox1.SelectedIndexChanged -= listBox1_SelectedIndexChanged;
            listBox1.DataSource = products = Products.GetProducts();
            listBox1.DisplayMember = "name";
            listBox1.ValueMember = "id";
            ClearListboxSelection();
            ClearFields();
            Common.MainForm.AcceptButton = button2;
            Common.MainForm.CancelButton = button3;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedValue == null) return;
            button4.Enabled = true;
            foreach (var li in products)
            {
                if (li.id == int.Parse(listBox1.SelectedValue.ToString()))
                {
                    current_id = li.id;
                    textBox1.Text = li.name;
                    numericUpDown1.Value = li.stock;
                    numericUpDown2.Value = li.price;
                    break;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button4.Enabled = false;
            current_id = 0;
            ClearListboxSelection();
            ClearFields();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Parent.Controls["productsForm1"].Visible = false;
            ClearFields();
            listBox1.SelectedIndexChanged -= listBox1_SelectedIndexChanged;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "" || numericUpDown1.Value == 0 || numericUpDown2.Value == 0)
            {
                MessageBox.Show("Ве молиме внесете ги сите полиња!", Common.GetCaption());
                return;
            }
            bool result;
            if (current_id == 0)
            {
                result = Products.AddProduct(textBox1.Text.Trim(), (int)numericUpDown1.Value, (int)numericUpDown2.Value);
            }
            else
            {
                result = Products.ModifyProduct(current_id, textBox1.Text.Trim(), (int)numericUpDown1.Value, (int)numericUpDown2.Value);
            }
            if (result)
            {
                ClearFields();
                LoadData();
                current_id = 0;
                MessageBox.Show("Успешно е ажуриран продуктот!", Common.GetCaption());
            }
            else
            {
                MessageBox.Show("Се случи грешка при ажурирање на продуктот!", Common.GetCaption());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (current_id == 0)
            {
                MessageBox.Show("Ве молиме одберете продукт за да избришете!", Common.GetCaption());
            }
            else
            {
                Products.DeleteProduct(current_id);
                ClearFields();
                LoadData();
                current_id = 0;
                button4.Enabled = false;
                MessageBox.Show("Успешно е избришан продуктот!", Common.GetCaption());
            }
        }

    }
}

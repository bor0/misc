﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule
{
    public partial class LicenseForm : UserControl
    {
        public LicenseForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LicenseModule.LicenseName = tb_ime_registrant.Text;
            LicenseModule.LicenseKey = tb_kluc.Text;
            LicenseModule.ValidUntil = dtp_datum.Value;
            bool result = LicenseModule.CheckLicenseObject();
            if (result)
            {
                LicenseModule.AddLicense();
                MessageBox.Show("Успешно е внесен регистрациониот код!", Common.GetCaption());
                Parent.Controls["licenseForm1"].Visible = false;
                ((MainForm)ParentForm).ShowLoginForm();
            }
            else
            {
                MessageBox.Show("Внесовте погрешен код!", Common.GetCaption());
                ((MainForm)Parent).closeButton = true;
                Application.Exit();
            }
        }

        private void LicenseForm_Load(object sender, EventArgs e)
        {
            Common.MainForm.AcceptButton = button1;
        }
    }
}


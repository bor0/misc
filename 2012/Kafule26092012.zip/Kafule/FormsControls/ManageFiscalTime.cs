﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule.FormsControls
{
    public partial class ManageFiscalTime : Form
    {
        public ManageFiscalTime()
        {
            InitializeComponent();
        }

        private void ManageFiscalTime_Load(object sender, EventArgs e)
        {
            string output = "";
            this.Text = Common.GetCaption();
            FiscalCash x = new FiscalCash();
            x.InitInterface();
            byte[] arr = x.GetTimeDate();
            for (int i = 0; i < arr.Length; i++) output += (char)arr[i];
            if (output.Contains("ERROR"))
            {
                MessageBox.Show("Се случи грешка при комуникација со Фискалната каса.\n" + output, Common.GetCaption());
            }
            else
            {
                dateTimePicker1.Value = DateTime.Parse(output.ToString() + ":00");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string output = "";
            FiscalCash x = new FiscalCash();
            x.InitInterface();
            byte[] arr = x.SetTimeDate(x.ConvertDateTimeToSynergyDate(dateTimePicker1.Value) + " " + dateTimePicker1.Value.Hour + ":" + dateTimePicker1.Value.Minute + ":" + dateTimePicker1.Value.Second);
            for (int i = 0; i < arr.Length; i++) output += (char)arr[i];
            if (output.Contains("ERROR"))
            {
                MessageBox.Show("Се случи грешка при комуникација со Фискалната каса.\n" + output, "Грешка");
            }
            else
            {
                MessageBox.Show("Успешно е наместено времето.");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;
using Kafule.FormsControls;

namespace Kafule.User_Controls
{
    public partial class ReservationForm : UserControl
    {

        public ReservationForm()
        {
            InitializeComponent();
        }

        public void ClearFields()
        {
            label4.Text = "";
            dataGridView1.Rows.Clear();
        }

        public void LoadData()
        {
            ClearFields();
            Common.MainForm.AcceptButton = button1;
            Common.MainForm.CancelButton = button3;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Parent.Controls["reservationForm1"].Visible = false;
            ClearFields();
        }

        public void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            ClearFields();
            int total_res = 0;
            bool trigger = false;
            foreach (var li in Reservations.GetReservationsByDate(Common.ParseStartDate(dateTimePicker1.Value), Common.ParseEndDate(dateTimePicker2.Value)))
            {
                trigger = true;
                string val1 = li.id.ToString();
                string val2 = li.reservation_name;
                string val3 = li.reservation_table.ToString();
                IList<User> user = ManageUsers.GetUserById(li.reserved_by);
                string full_name = "Вработен";
                if (user.Count != 0) full_name = user[0].first_name + " " + user[0].last_name;
                string val4 = full_name;
                string val5 = li.reservation_date.ToString("dd.MM.yyyy HH:mm");
                dataGridView1.Rows.Add(new object[]{val1, val2, val3, val4, val5});
                total_res++;
            }
            if (trigger) label4.Text = total_res.ToString();
            button1.Enabled = true;
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                int id = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                ManageReservation form = new ManageReservation(id);
                form.ShowDialog();
                button1_Click(null, null);
            }
            catch (Exception)
            {
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ManageReservation form = new ManageReservation();
            form.ShowDialog();
            button1_Click(null, null);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafule.Classes;

namespace Kafule.User_Controls
{
    public partial class LoginForm : UserControl
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ManageUsers.AuthenticateUser(tb_username.Text, tb_password.Text) == true)
            {
                Parent.Controls["loginForm1"].Visible = false;
                tb_username.Text = "";
                tb_password.Text = "";
                ((MainForm)ParentForm).ShowUserForm();
            }
            else
            {
                MessageBox.Show("Внесовте погрешно име или лозинка!", Common.GetCaption());
                tb_username.Focus();
            }
        }
    }
}

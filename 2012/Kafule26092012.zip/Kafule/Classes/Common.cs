﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Kafule.Classes
{
    class Common
    {
        private static DataClassDataContext data = null;
        public static int user_id;
        public static int user_status;
        public static System.Windows.Forms.Form MainForm;

        [DllImport("kernel32.dll")]
        private static extern long GetVolumeInformation(string PathName, StringBuilder VolumeNameBuffer, UInt32 VolumeNameSize, ref UInt32 VolumeSerialNumber, ref UInt32 MaximumComponentLength, ref UInt32 FileSystemFlags, StringBuilder FileSystemNameBuffer, UInt32 FileSystemNameSize);

        /// <summary>
        /// Get the serial number for drive letter. Returns decimal value (string)
        /// </summary>
        /// <param name="strDriveLetter"></param>
        /// <returns></returns>
        public static string GetVolumeSerial(string strDriveLetter)
        {
            uint serNum = 0;
            uint maxCompLen = 0;
            StringBuilder VolLabel = new StringBuilder(256); // Label
            UInt32 VolFlags = new UInt32();
            StringBuilder FSName = new StringBuilder(256); // File System Name
            strDriveLetter += ":\\"; // fix up the passed-in drive letter for the API call
            long Ret = GetVolumeInformation(strDriveLetter, VolLabel, (UInt32)VolLabel.Capacity, ref serNum, ref maxCompLen, ref VolFlags, FSName, (UInt32)FSName.Capacity);
            return Convert.ToString(serNum);
        }

        /// <summary>
        /// Get the DB context (Singleton)
        /// </summary>
        /// <returns></returns>
        public static DataClassDataContext GetDataContext()
        {
            if (data == null)
            {
                data = new DataClassDataContext();
            }
            return data;
        }

        /// <summary>
        /// B64 encode a string
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string Base64_Encode(string str)
        {
            byte[] encbuff = System.Text.Encoding.UTF8.GetBytes(str);
            return Convert.ToBase64String(encbuff);
        }

        /// <summary>
        /// B64 Decode a string
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string Base64_Decode(string str)
        {
            byte[] decbuff = Convert.FromBase64String(str);
            return System.Text.Encoding.UTF8.GetString(decbuff);
        }

        /// <summary>
        /// Calculate MD5 hash of a string
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string Calculate_MD5_Hash(string input)
        {
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString();
        }

        /// <summary>
        /// Gets caption
        /// </summary>
        /// <param name="msg"></param>
        public static string GetCaption()
        {
            string caption = "Кафуле v1.0";
            if (LicenseModule.LicenseName != null && LicenseModule.LicenseName != "")
            {
                caption = LicenseModule.LicenseName + " - " + caption;
            }
            return caption;
        }

        /// <summary>
        /// Convert start date
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static DateTime ParseStartDate(DateTime dt)
        {
            return new DateTime(dt.Year, dt.Month, dt.Day, 0, 0, 0);
        }

        /// <summary>
        /// Convert end date
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static DateTime ParseEndDate(DateTime dt)
        {
            return new DateTime(dt.Year, dt.Month, dt.Day, 23, 59, 59);
        }

    }
}
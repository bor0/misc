﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafule.Classes
{

    class ManageUsers
    {

        /// <summary>
        /// Add a user to DB
        /// </summary>
        /// <param name="first_name"></param>
        /// <param name="last_name"></param>
        /// <param name="login_name"></param>
        /// <param name="embg"></param>
        /// <param name="password"></param>
        /// <returns>True on success, false on error</returns>
        public static bool AddUser(string first_name, string last_name, string login_name, string embg, string phone, string password)
        {
            IList<User> users = (from c in Common.GetDataContext().Users where (c.login_name == login_name && c.is_deleted == false) select c).ToList();
            
            if (users.Count != 0)
            {
                return false;
            }
                
            User user = new User();
            user.first_name = first_name;
            user.last_name = last_name;
            user.login_name = login_name;
            user.phone = phone;
            user.embg = embg;
            user.password_hash = Common.Calculate_MD5_Hash(password);
            user.user_type = 2;
            user.is_deleted = false;
            user.date_created = DateTime.Now;
            Common.GetDataContext().Users.InsertOnSubmit(user);
            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Delete a user from DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns>True on success, false on error</returns>
        public static bool DeleteUser(int id)
        {
            IList<User> user = (from c in Common.GetDataContext().Users where (c.id == id && c.is_deleted == false) select c).ToList();

            if (user.Count == 0)
            {
                return false;
            }

            foreach (var li in user)
            {
                li.is_deleted = true;
            }
            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Authenticates user
        /// </summary>
        /// <param name="login_name"></param>
        /// <param name="password"></param>
        /// <returns>True on success, false on error</returns>
        public static bool AuthenticateUser(string login_name, string password)
        {
            IList<User> user = (from c in Common.GetDataContext().Users where (c.login_name == login_name && c.password_hash == Common.Calculate_MD5_Hash(password) && c.is_deleted == false) select c).ToList();
            if (user.Count == 0) return false;
            foreach (var li in user)
            {
                Common.user_id = li.id;
                Common.user_status = li.user_type;
            }

            return true;
        }

        /// <summary>
        /// Modifies an already existing user
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="first_name"></param>
        /// <param name="last_name"></param>
        /// <param name="login_name"></param>
        /// <param name="embg"></param>
        /// <param name="password"></param>
        /// <returns>True on success, false on error</returns>
        public static bool ModifyUser(int user_id, string first_name, string last_name, string login_name, string embg, string phone, string password)
        {
            IList<User> users = (from c in Common.GetDataContext().Users where (c.id == user_id && c.is_deleted == false) select c).ToList();
            if (users.Count == 0) return false;

            IList<User> userLoginUnique = (from c in Common.GetDataContext().Users where (c.id != user_id && c.login_name == login_name && c.is_deleted == false) select c).ToList();
            if (userLoginUnique.Count != 0) return false;

            foreach (var user in users) {
                user.first_name = first_name;
                user.last_name = last_name;
                user.login_name = login_name;
                user.embg = embg;
                user.phone = phone;
                user.password_hash = Common.Calculate_MD5_Hash(password);
                user.is_deleted = false;
                user.date_created = DateTime.Now;
            }

            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Get a list of all available users
        /// </summary>
        /// <returns></returns>
        public static IList<User> GetUsers()
        {
            return (from c in Common.GetDataContext().Users where c.is_deleted == false select c).ToList();
        }

        /// <summary>
        /// Get a list of user by id
        /// </summary>
        /// <returns></returns>
        public static IList<User> GetUserById(int id)
        {
            return (from c in Common.GetDataContext().Users where c.id == id && c.is_deleted == false select c).ToList();
        }

    }
}

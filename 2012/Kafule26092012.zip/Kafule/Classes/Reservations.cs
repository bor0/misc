﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafule.Classes
{
    class Reservations
    {

        /// <summary>
        /// Get reservations for date
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns>List of reservations on success, null on error</returns>
        public static IList<Reservation> GetReservationsByDate(DateTime start, DateTime end)
        {
            return (from c in Common.GetDataContext().Reservations where (start <= c.reservation_date && c.reservation_date <= end) select c).ToList();
        }

        /// <summary>
        /// Get reservations by id
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns>List of reservations on success, null on error</returns>
        public static IList<Reservation> GetReservationsById(int id)
        {
            return (from c in Common.GetDataContext().Reservations where (c.id == id) select c).ToList();
        }

        /// <summary>
        /// Deletes a reservation
        /// </summary>
        /// <param name="reservation_id"></param>
        /// <returns>True on success, false on error</returns>
        public static bool DeleteReservation(int reservation_id)
        {
            IList<Reservation> reservations = (from c in Common.GetDataContext().Reservations where (c.id == reservation_id) select c).ToList();

            if (reservations.Count == 0)
            {
                return false;
            }

            foreach (var li in reservations)
            {
                Common.GetDataContext().Reservations.DeleteOnSubmit(li);
            }
            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Adds a reservation
        /// </summary>
        /// <param name="reservation_name"></param>
        /// <param name="reservation_table"></param>
        /// <param name="reservation_date"></param>
        /// <returns>Returns -1 on error, reservation_id on success</returns>
        public static bool AddReservation(string reservation_name, int reservation_table, DateTime reservation_date)
        {
            Reservation reservation = new Reservation();
            reservation.reservation_name = reservation_name;
            reservation.reservation_date = reservation_date;
            reservation.reservation_table = reservation_table;
            reservation.reserved_by = Common.user_id;
            Common.GetDataContext().Reservations.InsertOnSubmit(reservation);
            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Modifies a reservation
        /// </summary>
        /// <param name="id"></param>
        /// <param name="reservation_name"></param>
        /// <param name="reservation_table"></param>
        /// <param name="reservation_date"></param>
        /// <returns>Returns true on success, false on error</returns>
        public static bool ModifyReservation(int id, string reservation_name, int reservation_table, DateTime reservation_date)
        {

            IList<Reservation> reservation = (from c in Common.GetDataContext().Reservations where (c.id == id) select c).ToList();

            if (reservation.Count == 0)
            {
                return false;
            }

            foreach (var li in reservation)
            {
                li.reservation_name = reservation_name;
                li.reservation_date = reservation_date;
                li.reservation_table = reservation_table;
                li.reserved_by = Common.user_id;
            }

            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}

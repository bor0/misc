﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kafule.Properties;

namespace Kafule.Classes
{
    class LicenseModule
    {

        public static DateTime ValidUntil;
        public static string LicenseName;
        public static string LicenseKey;
        private static string HddSerial;

        /// <summary>
        /// Check status license
        /// </summary>
        /// <returns>1 on success, -1 if no license is entered, -2 if deserialization fails, -3 if expired, -4 if invalid key</returns>
        public static int CheckLicense()
        {
            string LicenseSerialized = Settings.Default["License"].ToString();
            
            if (LicenseSerialized == "")
            {
                return -1;
            }

            if (DeserializeLicense(LicenseSerialized) == false)
            {
                return -2;
            }

            if (DateTime.Now > ValidUntil)
            {
                return -3;
            }

            if (CheckLicenseObject() == false)
            {
                return -4;
            }

            return 1;
        }

        /// <summary>
        /// Check the license entered in the object
        /// </summary>
        /// <returns></returns>
        public static bool CheckLicenseObject()
        {
            string LicenseKeyBuilder = ValidUntil.Day.ToString() + "." + ValidUntil.Month.ToString() + "." + ValidUntil.Year.ToString() + " " + Common.GetVolumeSerial("C") + " " + LicenseName;
            if (LicenseKey != Common.Calculate_MD5_Hash(LicenseKeyBuilder).ToLower())
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Register license and check for its validity
        /// </summary>
        /// <returns></returns>
        public static void AddLicense()
        {
            Settings.Default["License"] = SerializeLicense();
            Settings.Default.Save();
        }

        /// <summary>
        /// Deserializes license from Settings
        /// </summary>
        /// <param name="license"></param>
        /// <returns>True on success, false on error</returns>
        private static bool DeserializeLicense(string license)
        {
            string[] LicenseDetails = Common.Base64_Decode(license).Split(',');
            try
            {
                ValidUntil = DateTime.Parse(LicenseDetails[0]);
                LicenseName = LicenseDetails[1];
                LicenseKey = LicenseDetails[2];
                HddSerial = LicenseDetails[3];
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Serializes License
        /// </summary>
        /// <returns>License string</returns>
        private static string SerializeLicense()
        {
            return Common.Base64_Encode(ValidUntil.Day + "." + ValidUntil.Month + "." + ValidUntil.Year + "," + LicenseName.Replace(",", "") + "," + LicenseKey.Replace(",", "").ToLower() + "," + HddSerial);
        }

    }
}

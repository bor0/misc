﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kafule.Properties;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;

namespace Kafule.Classes
{
    class FiscalCash
    {

        bool initialized = false;
        string ComPort;

        IList<byte> opcodes = new List<byte>();
        StringBuilder FileIn = new StringBuilder(255);
        StringBuilder FileOut = new StringBuilder(255);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public static extern int GetShortPathName(
                 [MarshalAs(UnmanagedType.LPTStr)]
                   string path,
                 [MarshalAs(UnmanagedType.LPTStr)]
                   StringBuilder shortPath,
                 int shortPathLength
        );

        /// <summary>
        /// Initialize raw command to fiscal printer
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        private byte[] InitRawCommand(string command)
        {
            CheckInterfaceInit();
            AppendStringToOpcodes(command);

            byte[] returnVal = StartProcessAndWait();

            try
            {
                CloseInterface();
            }
            catch (Exception) { }

            return returnVal;
        }

        /// <summary>
        /// Start process bsipf500.exe and wait
        /// </summary>
        /// <returns></returns>
        private byte[] StartProcessAndWait()
        {
            File.WriteAllBytes(FileIn.ToString(), opcodes.ToArray());
            Process process = new Process();
            process.StartInfo.FileName = "bsipf500.exe";
            process.StartInfo.Arguments = ComPort + " " + FileIn.ToString() + " " + FileOut.ToString();
            process.Start();
            process.WaitForExit();
            return File.ReadAllBytes(FileOut.ToString());
        }

        /// <summary>
        /// Check if interface is initialized
        /// </summary>
        private void CheckInterfaceInit()
        {
            if (initialized == false) throw new Exception("Ne e inicijaliziran interfejsot.");
        }

        /// <summary>
        /// Prase product name (cyrillic)
        /// </summary>
        /// <param name="ProductName"></param>
        /// <returns></returns>
        private string ParseProductName(string ProductName)
        {
            string retval = "";
            for (int i = 0; i < ProductName.Length; i++)
            {
                switch (ProductName[i])
                {
                    case 'А': retval += 'A'; break;
                    case 'Б': retval += 'B'; break;
                    case 'В': retval += 'V'; break;
                    case 'Г': retval += 'G'; break;
                    case 'Д': retval += 'D'; break;
                    case 'Ѓ': retval += '\\'; break;
                    case 'Е': retval += 'E'; break;
                    case 'Ж': retval += '@'; break;
                    case 'З': retval += 'Z'; break;
                    case 'Ѕ': retval += 'Y'; break;
                    case 'И': retval += 'I'; break;
                    case 'Ј': retval += 'J'; break;
                    case 'К': retval += 'K'; break;
                    case 'Л': retval += 'L'; break;
                    case 'Љ': retval += 'Q'; break;
                    case 'М': retval += 'M'; break;
                    case 'Н': retval += 'N'; break;
                    case 'Њ': retval += 'W'; break;
                    case 'О': retval += 'O'; break;
                    case 'П': retval += 'P'; break;
                    case 'Р': retval += 'R'; break;
                    case 'С': retval += 'S'; break;
                    case 'Т': retval += 'T'; break;
                    case 'Ќ': retval += ']'; break;
                    case 'У': retval += 'U'; break;
                    case 'Ф': retval += 'F'; break;
                    case 'Х': retval += 'H'; break;
                    case 'Ц': retval += 'C'; break;
                    case 'Ч': retval += '^'; break;
                    case 'Џ': retval += 'X'; break;
                    case 'Ш': retval += '['; break;
                    case 'а': retval += 'a'; break;
                    case 'б': retval += 'b'; break;
                    case 'в': retval += 'v'; break;
                    case 'г': retval += 'g'; break;
                    case 'д': retval += 'd'; break;
                    case 'ѓ': retval += '|'; break;
                    case 'е': retval += 'e'; break;
                    case 'ж': retval += '`'; break;
                    case 'з': retval += 'z'; break;
                    case 'ѕ': retval += 'y'; break;
                    case 'и': retval += 'i'; break;
                    case 'ј': retval += 'j'; break;
                    case 'к': retval += 'k'; break;
                    case 'л': retval += 'l'; break;
                    case 'љ': retval += 'q'; break;
                    case 'м': retval += 'm'; break;
                    case 'н': retval += 'n'; break;
                    case 'њ': retval += 'w'; break;
                    case 'о': retval += 'o'; break;
                    case 'п': retval += 'p'; break;
                    case 'р': retval += 'r'; break;
                    case 'с': retval += 's'; break;
                    case 'т': retval += 't'; break;
                    case 'ќ': retval += '}'; break;
                    case 'у': retval += 'u'; break;
                    case 'ф': retval += 'f'; break;
                    case 'х': retval += 'h'; break;
                    case 'ц': retval += 'c'; break;
                    case 'ч': retval += '~'; break;
                    case 'џ': retval += 'x'; break;
                    case 'ш': retval += '{'; break;
                    default: retval += ProductName[i]; break;
                }
            }
            return retval;
        }

        /// <summary>
        /// Append bytes to opcodes for raw command
        /// </summary>
        /// <param name="opcode"></param>
        private void AppendStringToOpcodes(string opcode)
        {
            byte[] tmp = Encoding.ASCII.GetBytes(opcode);
            for (int i = 0; i < opcode.Length; i++) opcodes.Add(tmp[i]);
        }

        /// <summary>
        /// Checks if printer is set in configuration file
        /// </summary>
        /// <returns></returns>
        public static bool isPrinterSet()
        {
            if (Settings.Default["FiscalPort"] != null && Settings.Default["FiscalPort"].ToString() != "") return true;
            return false;
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~FiscalCash()
        {
            try
            {
                CloseInterface();
            }
            catch (Exception) { }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="ComPort"></param>
        public FiscalCash(string ComPort = null)
        {
            if (ComPort == null)
            {
                ComPort = Settings.Default["FiscalPort"].ToString();
            }
            this.ComPort = ComPort;
        }

        /// <summary>
        /// Initialize fiscal printer interface
        /// </summary>
        public void InitInterface()
        {
            if (initialized == true) throw new Exception("Interfejsot e vekje inicijaliziran.");
            initialized = true;

            GetShortPathName(@Path.GetTempFileName(), FileIn, FileIn.Capacity);
            GetShortPathName(@Path.GetTempFileName(), FileOut, FileOut.Capacity);

        }

        /// <summary>
        /// Close fiscal printer interface
        /// </summary>
        public void CloseInterface()
        {
            if (initialized == false) throw new Exception("Interfejsot e vekje zatvoren.");
            initialized = false;
            opcodes.Clear();
            File.Delete(FileIn.ToString());
            File.Delete(FileOut.ToString());
        }

        /// <summary>
        /// Issue all added products
        /// </summary>
        /// <returns></returns>
        public byte[] IssueBill()
        {
            return InitRawCommand("5\t\r\n8 \r\n\r\n");
        }

        /// <summary>
        /// Issue all added storno products
        /// </summary>
        /// <returns></returns>
        public byte[] IssueStorno()
        {
            return InitRawCommand("5\t\r\nV \r\n\r\n");
        }

        /// <summary>
        /// Daily financial report
        /// </summary>
        /// <returns></returns>
        public byte[] DailyFiscalClose()
        {
            return InitRawCommand("E\r\n");
        }

        /// <summary>
        /// Get time and date for fiscal
        /// </summary>
        /// <returns></returns>
        public byte[] GetTimeDate()
        {
            return InitRawCommand(">\r\n");
        }

        /// <summary>
        /// Set time and date
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public byte[] SetTimeDate(string time)
        {
            return InitRawCommand("=" + time + "\r\n");
        }

        /// <summary>
        /// Init detailed report
        /// </summary>
        /// <param name="timeStart"></param>
        /// <param name="timeEnd"></param>
        /// <returns></returns>
        public byte[] DetailedReport(string timeStart, string timeEnd)
        {
            return InitRawCommand("^" + timeStart + "," + timeEnd + "\r\n");
        }

        /// <summary>
        /// Init short report
        /// </summary>
        /// <param name="timeStart"></param>
        /// <param name="timeEnd"></param>
        /// <returns></returns>
        public byte[] ShortReport(string timeStart, string timeEnd)
        {
            return InitRawCommand("O" + timeStart + "," + timeEnd + "\r\n");
        }

        /// <summary>
        /// Add a product
        /// </summary>
        /// <param name="ProductName"></param>
        /// <param name="ProductPrice"></param>
        /// <param name="Quantity"></param>
        /// <param name="TaxCategory">192 = А (default), 193 = Б, 194 = В, 195 = Г</param>
        public void AddProduct(string ProductName, string ProductPrice, string Quantity = "1.000", byte TaxCategory = 192)
        {
            CheckInterfaceInit();
            if (opcodes.Count == 0) AppendStringToOpcodes("01,0000,1\r\n");
            AppendStringToOpcodes("1" + ParseProductName(ProductName) + "\t");
            opcodes.Add(TaxCategory);
            AppendStringToOpcodes(ProductPrice + "*" + Quantity + "\r\n");
        }

        /// <summary>
        /// Add a product for Storno
        /// </summary>
        /// <param name="ProductName"></param>
        /// <param name="ProductPrice"></param>
        /// <param name="Quantity"></param>
        public void AddProductStorno(string ProductName, string ProductPrice, string Quantity = "1.000")
        {
            CheckInterfaceInit();
            if (opcodes.Count == 0) AppendStringToOpcodes("U1,0000,1\r\n");
            AppendStringToOpcodes("1" + ParseProductName(ProductName) + "\t");
            opcodes.Add(0xC0);
            AppendStringToOpcodes(ProductPrice + "*" + Quantity + "\r\n");
        }

        /// <summary>
        /// Converts DateTime to synergy date
        /// </summary>
        /// <param name="value"></param>
        /// <param name="dash"></param>
        /// <returns></returns>
        public string ConvertDateTimeToSynergyDate(DateTime value, bool dash = true)
        {
            string DD = value.Day.ToString("D2"), MM = value.Month.ToString("D2"), YY = (value.Year - 2000).ToString("D2");
            return DD + ((dash == true) ? "-" : "") + MM + ((dash == true) ? "-" : "") + YY;
        }

    }
}

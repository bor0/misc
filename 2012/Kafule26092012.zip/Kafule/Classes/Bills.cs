﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafule.Classes
{
    class Bills
    {

        public class ListBoxValues
        {
            public string Value { get; set;}
    	    public int ID {get; set;}
        }

        /// <summary>
        /// Issues a bill
        /// </summary>
        /// <param name="products"></param>
        /// <returns>True on success, false on error</returns>
        public static bool IssueBill(IList<BillProduct> products, int table)
        {

            Bill bill = new Bill();
            bill.billed_by = Common.user_id;
            bill.bill_date = DateTime.Now;
            bill.bill_table = table;

            Common.GetDataContext().Bills.InsertOnSubmit(bill);

            try
            {
                Common.GetDataContext().SubmitChanges();
            }
            catch (Exception)
            {
                return false;
            }

            foreach (var product in products)
            {
                BillDetail bd = new BillDetail();
                bd.bill_id = bill.id;
                bd.price = product.price;
                bd.product_name = product.name;
                bd.quantity = product.quantity;
                Products.DecreaseStock(product.id, product.quantity);
                Common.GetDataContext().BillDetails.InsertOnSubmit(bd);
            }

            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        /// <summary>
        /// Get bills by date
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns>List of bills on success, null on error</returns>
        public static IList<Bill> GetBills(DateTime start, DateTime end)
        {
            return (from c in Common.GetDataContext().Bills where (start <= c.bill_date && c.bill_date <= end) select c).ToList();
        }

        /// <summary>
        /// Get bill details for bill_id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static IList<BillDetail> GetBillDetails(int id)
        {
            return (from c in Common.GetDataContext().BillDetails where (c.bill_id == id) select c).ToList();
        }

        /// <summary>
        /// Deletes a bill along with BillDetails objects
        /// </summary>
        /// <param name="bill_id"></param>
        /// <returns>True on success, false on error</returns>
        public static bool DeleteBill(int bill_id)
        {
            IList<Bill> bills = (from c in Common.GetDataContext().Bills where (c.id == bill_id) select c).ToList();

            if (bills.Count == 0)
            {
                return false;
            }

            foreach (var li in bills)
            {
                foreach (var li2 in GetBillDetails(li.id)) {
                    Common.GetDataContext().BillDetails.DeleteOnSubmit(li2);
                }
                Common.GetDataContext().Bills.DeleteOnSubmit(li);
            }
            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}

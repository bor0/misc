﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafule.Classes
{

    class BillProduct
    {
        public int id = 0;
        public int quantity = 0;
        public int price = 0;
        public string name = "";
    }

    class Products
    {

        /// <summary>
        /// Add a product
        /// </summary>
        /// <param name="name"></param>
        /// <param name="stock"></param>
        /// <param name="price"></param>
        /// <returns>True on success, false on error</returns>
        public static bool AddProduct(string name, int stock, int price)
        {
            IList<Product> products = (from c in Common.GetDataContext().Products where (c.name == name) select c).ToList();

            if (products.Count != 0)
            {
                return false;
            }

            Product product = new Product();
            product.name = name;
            product.stock = stock;
            product.price = price;
            Common.GetDataContext().Products.InsertOnSubmit(product);

            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        /// <summary>
        /// Delete a product from DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns>True on success, false on error</returns>
        public static bool DeleteProduct(int id)
        {
            IList<Product> product = (from c in Common.GetDataContext().Products where (c.id == id) select c).ToList();

            if (product.Count == 0)
            {
                return false;
            }

            foreach (var li in product)
            {
                Common.GetDataContext().Products.DeleteOnSubmit(li);
            }
            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Modifies an already existing product
        /// </summary>
        /// <param name="product_id"></param>
        /// <param name="name"></param>
        /// <param name="stock"></param>
        /// <param name="price"></param>
        /// <returns>True on success, false on error</returns>
        public static bool ModifyProduct(int product_id, string name, int stock, int price)
        {
            IList<Product> products = (from c in Common.GetDataContext().Products where (c.id == product_id) select c).ToList();
            if (products.Count == 0) return false;

            foreach (var product in products)
            {
                product.name = name;
                product.stock = stock;
                product.price = price;
            }

            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Decrease stock by 1 of a product
        /// </summary>
        /// <param name="product_id"></param>
        /// <returns>True on success, false on error</returns>
        public static bool DecreaseStock(int product_id, int quantity)
        {
            IList<Product> products = (from c in Common.GetDataContext().Products where (c.id == product_id) select c).ToList();

            if (products.Count == 0) return false;

            foreach (var product in products)
            {
                product.stock -= quantity;
            }

            try
            {
                Common.GetDataContext().SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Get a list of all products
        /// </summary>
        /// <returns></returns>
        public static IList<Product> GetProducts()
        {
            return (from c in Common.GetDataContext().Products select c).ToList();
        }
    }
}

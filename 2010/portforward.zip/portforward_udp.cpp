/*
  Port Forwarding Utility written by Boro Sitnikovski/EIN-SOF
  Written 02.06.2010
*/

#include <windows.h>
#include <stdio.h>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "wsock32.lib")

SERVICE_STATUS			ServiceStatus; 
SERVICE_STATUS_HANDLE	hStatus; 
 
void ServiceMain(int argc, char** argv); 
void ControlHandler(DWORD request); 
int InitService();

void main() 
{ 
	SERVICE_TABLE_ENTRY ServiceTable[2];
	ServiceTable[0].lpServiceName = "BoroDNS";
	ServiceTable[0].lpServiceProc = (LPSERVICE_MAIN_FUNCTION)ServiceMain;
	ServiceTable[1].lpServiceName = NULL;
	ServiceTable[1].lpServiceProc = NULL;
	StartServiceCtrlDispatcher(ServiceTable);
}

void ServiceMain(int argc, char** argv) {
	char buf[65535];
	int error;
	SOCKET os;
	struct sockaddr_in a, sa, da;
	WSADATA w;
	char buff1[16], buff2[8], buff3[16], buff4[8];
	WORD wVersionRequested;
	WSADATA wsaData;
	sockaddr_in sin;

 	ServiceStatus.dwServiceType = SERVICE_WIN32; 
	ServiceStatus.dwCurrentState = SERVICE_START_PENDING; 
	ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
	ServiceStatus.dwWin32ExitCode = 0; 
	ServiceStatus.dwServiceSpecificExitCode = 0; 
	ServiceStatus.dwCheckPoint = 0; 
	ServiceStatus.dwWaitHint = 0; 

 	printf("Port forwarding utility written by Boro Sitnikovski/EIN-SOF\n");

	FILE *test = fopen("D:\\borodns.cfg", "r");

	hStatus = RegisterServiceCtrlHandler("BoroDNS", (LPHANDLER_FUNCTION)ControlHandler); 
	if (hStatus == (SERVICE_STATUS_HANDLE)0) return;
	error = InitService(); 

	if (!test || error) {
		if (test) fclose(test);
		ServiceStatus.dwCurrentState = SERVICE_STOPPED; 
		ServiceStatus.dwWin32ExitCode = -1; 
		SetServiceStatus(hStatus, &ServiceStatus); 
		return; 
	}
	else {
		//fscanf(test, "%15s%6s%15s%6s", buff1, buff2, buff3, buff4);
		fscanf(test, "%15s%15s", buff1, buff3);
		strcpy(buff2, "53");
		strcpy(buff4, buff2);
		fclose(test);
	}
	WSAStartup(0x0101, &w);
	os=socket(PF_INET,SOCK_DGRAM,IPPROTO_IP);

	a.sin_family=AF_INET;
	a.sin_addr.s_addr=inet_addr(buff1);
	a.sin_port=htons((u_short)atoi(buff2));

	if(bind(os,(struct sockaddr *)&a,sizeof(a)) == -1) {
		ServiceStatus.dwCurrentState = SERVICE_STOPPED; 
		ServiceStatus.dwWin32ExitCode = -1; 
		SetServiceStatus(hStatus, &ServiceStatus); 
		return; 
	}
	a.sin_addr.s_addr=inet_addr(buff3);
	a.sin_port=htons((u_short)atoi(buff4));

	da.sin_addr.s_addr=0;

	ServiceStatus.dwCurrentState = SERVICE_RUNNING; 
	SetServiceStatus(hStatus, &ServiceStatus);

	while (ServiceStatus.dwCurrentState == SERVICE_RUNNING) {
		int sn=sizeof(sa);
		int n=recvfrom(os,buf,sizeof(buf),0,(struct sockaddr *)&sa,&sn);
		if(n<=0) continue;

		if (da.sin_addr.s_addr && sa.sin_addr.s_addr==a.sin_addr.s_addr && sa.sin_port==a.sin_port) {
			sendto(os,buf,n,0,(struct sockaddr *)&da,sizeof(da));
		} else {
			sendto(os,buf,n,0,(struct sockaddr *)&a,sizeof(a));
			da=sa;
		}
	}
	closesocket(os);
	WSACleanup();
	return; 
}

void ControlHandler(DWORD request) { 
	switch(request) { 
		case SERVICE_CONTROL_STOP: 
			ServiceStatus.dwWin32ExitCode = 0; 
			ServiceStatus.dwCurrentState = SERVICE_STOPPED; 
			SetServiceStatus (hStatus, &ServiceStatus);
			return; 
 
		case SERVICE_CONTROL_SHUTDOWN: 
			ServiceStatus.dwWin32ExitCode = 0; 
			ServiceStatus.dwCurrentState = SERVICE_STOPPED; 
			SetServiceStatus (hStatus, &ServiceStatus);
			return; 
		
		default:
			break;
	 } 
 
	 SetServiceStatus (hStatus, &ServiceStatus);
 
	 return; 
}

int InitService() {
	return 0;
}
import System.Process (runCommand)
import Control.Monad (when, unless)
import Control.Concurrent (forkIO, threadDelay, killThread)
import Control.Exception
import Data.Foldable (forM_)
import System.Time
import Data.Maybe (fromJust, isJust)
import Network.HaskellNet.IMAP
import Network.HaskellNet.IMAP.SSL

data Cfg = Cfg {
      server :: String
    , username :: String
    , password :: String
}

main = do
    cfg <- readFile "/home/boro/.mailnotify.cfg"
    listOfThreads <- mapM go (lines cfg)
    loop listOfThreads
    where
    go line = forkIO $ runForAccount line 0
    loop threads = do
        s <- getLine
        unless (s == "exit") $ loop threads
        mapM_ killThread threads

readCfg :: [String] -> Maybe Cfg
readCfg [s, u, p] = Just $ Cfg s u p
readCfg _         = Nothing

getPrintPrefix :: IO String
getPrintPrefix = do
    curtime <- getClockTime
    return $ "[" ++ show curtime ++ "] "

prettyPrint :: String -> Int -> IO ()
prettyPrint username messages = do
    time <- getPrintPrefix
    putStrLn $ time ++ username ++ ": " ++ show messages ++ " new message(s)"
    runCommand $ "notify-send \"" ++ time ++ "\" \"" ++ username ++ ": " ++ show messages ++ " new message(s)\""
    return ()

getUnreadMailMessages :: Cfg -> IO (Maybe Int)
getUnreadMailMessages cfg = do
    x <- go cfg :: IO (Either SomeException Int)
    case x of
      Right a -> return $ Just a
      Left b  -> do
        when (show b /= "thread killed") $ do -- dirty hack to show exceptions except this one (when we quit)
            time <- getPrintPrefix
            putStrLn $ time ++ show (server cfg, b)
        return Nothing
    where 
    go cfg = try $ do
        con <- connectIMAPSSL $ server cfg
        login con (username cfg) (password cfg)
        select con "INBOX"
        msgs <- search con [UNFLAG Seen]
        let num = length msgs
        close con
        return num

runForAccount :: String -> Int -> IO ()
runForAccount line messages = do
    let cfg' = readCfg (words line)
    forM_ cfg' loop
    where
    loop cfg = do
        num <- getUnreadMailMessages cfg
        when (isJust num && fromJust num /= 0) $ prettyPrint (username cfg) (fromJust num)
        threadDelay 300000000
        loop cfg

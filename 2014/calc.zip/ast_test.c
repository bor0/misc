#include <stdio.h>

#include "ast.h"

int main(void)
{
    struct calc_ast *ast;
    MP_INT x, y, z, res;

    mpz_init_set_str(&x, "2", 10);
    mpz_init_set_str(&y, "3", 10);
    mpz_init_set_str(&z, "4", 10);

    ast = ast_new_calc(
        '*',
        ast_new_number(x),
        ast_new_calc(
            '+',
            ast_new_number(y),
            ast_new_number(z)
        )
    );

    res = ast_eval(ast);

    gmp_printf("%Zd\n", &res);

    ast_free(ast);

    mpz_clear(&x);
    mpz_clear(&y);
    mpz_clear(&z);

    return 0;
}

#ifndef LIST_H
#define LIST_H
#include <gmp.h>

struct linked_list {
    char *varname;
    MP_INT val;
    struct linked_list *next;
};

void list_print(struct linked_list *);
MP_INT list_get(struct linked_list *, char *);
void list_add(struct linked_list *, char *, MP_INT);
struct linked_list *list_init();
void list_free(struct linked_list *);
#endif

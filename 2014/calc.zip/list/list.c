#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "list.h"

void list_print(struct linked_list *list)
{
    putchar('[');

    while (list != NULL) {
        gmp_printf("%s = %Zd, ", list->varname, &list->val);
        list = list->next;
    }

    printf("\b\b]\n");
}

MP_INT list_get(struct linked_list *list, char *varname)
{
    MP_INT ret;

    while (list != NULL) {
        if (list->varname != NULL && strcmp(list->varname, varname) == 0) {
            return list->val;
        }
        list = list->next;
    }

    mpz_init(&ret);
    mpz_set_str(&ret, "0", 10);

    return ret;
}

void list_add(struct linked_list *list, char *varname, MP_INT val)
{
    MP_INT val2;

    mpz_init_set(&val2, &val);

    struct linked_list *tmp;

    while (list != NULL) {
        if (list->varname == NULL) {
            list->varname = strdup(varname);
        }
        if (strcmp(list->varname, varname) == 0) {
             list->val = val2;
             return;
        }
        tmp = list;
        list = list->next;
    }

    tmp->next = malloc(sizeof(struct linked_list));
    tmp->next->varname = strdup(varname);
    tmp->next->val = val2;
    tmp->next->next = NULL;
}

struct linked_list *list_init()
{
    struct linked_list *list = malloc(sizeof(struct linked_list));
    list->varname = NULL;
    list->next = NULL;
    return list;
}

void list_free(struct linked_list *list)
{
    struct linked_list *tmp;

    while (list != NULL) {
        free(list->varname);
        mpz_clear(&list->val);
        tmp = list;
        list = list->next;
        free(tmp);
    }
}

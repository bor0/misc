#ifndef AST_H
#define AST_H
#include <gmp.h>

#define DEBUG 0

enum tag { AST_OP, AST_NUMBER };

struct calc_ast {
    enum tag tag;
    union {
        char op;
        MP_INT number;
    } val;
    struct calc_ast *l, *r;
};

struct calc_ast *ast_new_op(char);
struct calc_ast *ast_new_number(MP_INT);
struct calc_ast *ast_new_calc(char, struct calc_ast *, struct calc_ast *);
void ast_free(struct calc_ast *);
MP_INT ast_eval(struct calc_ast *);
#endif

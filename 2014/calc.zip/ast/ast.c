#include <stdio.h>
#include <stdlib.h>

#include "ast.h"

struct calc_ast *ast_new_op(char op)
{
    struct calc_ast *ast = malloc(sizeof(struct calc_ast));
    ast->tag = AST_OP;
    ast->val.op = op;
    ast->l = ast->r = NULL;
#if DEBUG 
    printf("alloc_op %p\n", (void *)ast);
#endif
    return ast;
}

struct calc_ast *ast_new_number(MP_INT number)
{
    struct calc_ast *ast = malloc(sizeof(struct calc_ast));

    ast->tag = AST_NUMBER;
    mpz_init_set(&ast->val.number, &number);
    ast->l = ast->r = NULL;
#if DEBUG 
    printf("alloc_number %p (num = %p)\n", (void *)ast, (void *)&ast->val.number);
#endif
    return ast;
}

struct calc_ast *ast_new_calc(char op, struct calc_ast *a, struct calc_ast *b)
{
    struct calc_ast *ast = ast_new_op(op);
    ast->l = a;
    ast->r = b;
    return ast;
}

void ast_free(struct calc_ast *ast)
{
    if (ast->l) ast_free(ast->l);
    if (ast->r) ast_free(ast->r);

#if DEBUG 
    printf("freeing %p", (void *)ast);
    if (ast->tag == AST_NUMBER) {
        printf(" (num = %p)", (void *)&ast->val.number);
    }
    putchar('\n');
#endif

    if (ast->tag == AST_NUMBER) {
        mpz_clear(&ast->val.number);
    }

    free(ast);
}

MP_INT ast_eval(struct calc_ast *ast)
{
    static int init = 0;
    static MP_INT zero, one;
    MP_INT p, q, ret;

    if (!init) {
        init = 1;
        mpz_init_set_str(&zero, "0", 10);
        mpz_init_set_str(&zero, "1", 10);
    }

    ret = zero;

    switch (ast->tag) {
    case AST_OP:
        p = ast_eval(ast->l);
        q = ast_eval(ast->r);
        switch (ast->val.op) {
        case '=':
            if (mpz_cmp(&p, &q)) {
                ret = one;
            }
            break;
        case '!':
            if (!mpz_cmp(&p, &q)) {
                ret = one;
            }
            break;
        case '+':
            mpz_add(&ret, &p, &q);
            break;
        case '-':
            mpz_sub(&ret, &p, &q);
            break;
        case '*':
            mpz_mul(&ret, &p, &q);
            break;
        case '/':
            if (!mpz_cmp(&q, &zero)) {
                ret = zero;
            } else {
                mpz_div(&ret, &p, &q);
            }
            break;
        }
        break;
    case AST_NUMBER:
        ret = ast->val.number;
        break;
    }

    return ret;
}

{-# LANGUAGE ForeignFunctionInterface #-}
module Test where
import Foreign.C
 
foreign import ccall "test" test :: CInt -> Int
foreign import ccall "test" test2 :: CInt -> IO Int

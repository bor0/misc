#include <stdio.h>
#include "test.h"

int test(int n) {
    return n+1;
}

int test2(int n) {
    return n+1;
}

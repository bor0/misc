module Main where
import qualified Test
 
main = do
    let x = Test.test 123
    y <- Test.test2 $ fromIntegral x
    print (x, y)
    return ()

int test(int n);
int test2(int n);

{-# LANGUAGE OverloadedStrings #-}

import Web.Scotty

import Data.Monoid (mconcat)
import qualified Data.Text.Lazy as TL
import qualified Data.ByteString.Char8 as BS
import qualified Data.ByteString.Lazy.Char8 as BSL
import qualified Data.Text.Encoding as TE
import qualified Data.Text as T
import Data.Aeson

import System.Random (randomRIO)

import qualified Database.MySQL.Simple as MS
import Database.MySQL.Simple.Result
import Database.MySQL.Simple.QueryResults

import Control.Monad.IO.Class (liftIO)
import Control.Applicative
import Control.Monad

import qualified Database.Redis as R


data Room = Room { room_id :: Int, key_code :: Int } deriving Show

instance FromJSON Room where
 parseJSON (Object v) =
    Room <$> v .: "room_id"
         <*> v .: "key_code"
 parseJSON _ = mzero

instance ToJSON Room where
 toJSON (Room roomId keyCode) =
    object [ "room_id"  .= roomId
           , "key_code" .= keyCode
             ]

instance QueryResults Room where
    convertResults [fa,fb] [va,vb] = Room a b
        where a = convert fa va
              b = convert fb vb
    convertResults fs vs  = convertError fs vs 1

convertToJSON x = BSL.unpack $ encode $ toJSON x

main = scotty 3000 $ do
    redisConn <- liftIO $ R.connect R.defaultConnectInfo

    get "/" $ file "static/index.html"

    get "/rooms" $ do
        sqlConn <- liftIO $ MS.connect MS.defaultConnectInfo { MS.connectPassword = "", MS.connectDatabase = "hotels" }
        rows <- liftIO $ MS.query_ sqlConn "SELECT * FROM rooms"
        liftIO $ MS.close sqlConn
        html $ TL.pack $ convertToJSON (rows :: [Room])

    get "/rooms/:room_id" $ do
        room_id <- param "room_id"
        sqlConn <- liftIO $ MS.connect MS.defaultConnectInfo { MS.connectPassword = "", MS.connectDatabase = "hotels" }
        rows <- liftIO $ MS.query sqlConn "SELECT * FROM rooms WHERE room_id = ?" (MS.Only (room_id :: Int))
        liftIO $ MS.close sqlConn
        html $ TL.pack $ convertToJSON (rows :: [Room])

    put "/rooms/gencode" $ do
        sqlConn <- liftIO $ MS.connect MS.defaultConnectInfo { MS.connectPassword = "", MS.connectDatabase = "hotels" }
        room_id <- param "room_id"
        key_code <- liftIO (randomRIO (1000, 9999) :: IO Int)
        liftIO $ do
            R.runRedis redisConn $ R.publish (TE.encodeUtf16LE room_id) (BS.pack . show $ key_code)
            MS.execute sqlConn "UPDATE rooms SET key_code = ? WHERE room_id = ?" [T.pack $ show key_code, room_id]
            MS.close sqlConn
        html $ (TL.pack . show) key_code

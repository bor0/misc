def answer_rec(x, y, z, memo, digits):
    if z == 1:
        if x == y:
            memo[(x, y, z)] = 1
        else:
            memo[(x, y, z)] = 0

    if (x, y, z) in memo:
        return memo[(x, y, z)]

    s = 0

    for next_digit in digits[x]:
         s += answer_rec(next_digit, y, z - 1, memo, digits)

    memo[(x, y, z)] = s
    return s

def answer(x, y, z):
    memo = {}

    digits = {
        0: [4, 6],
        1: [6, 8],
        2: [7, 9],
        3: [4, 8],
        4: [3, 9, 0],
        5: [],
        6: [1, 7, 0],
        7: [2, 6],
        8: [1, 3],
        9: [2, 4]
    }

    return str(answer_rec(x, y, z, memo, digits))

print(answer(6, 2, 5))
print(answer(1, 5, 100))
print(answer(3, 7, 1))

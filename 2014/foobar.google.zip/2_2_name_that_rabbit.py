def diff_names(name1, name2):
    s_1 = 0
    for c in name1:
        s_1 += ord(c) - 96

    s_2 = 0
    for c in name2:
        s_2 += ord(c) - 96

    if s_1 == s_2:
        names = sorted([name1, name2], reverse = True)
        if names[0] == name1:
            return -1
        else:
            return 1
    else:
        return s_2 - s_1

def answer(names):
    return sorted(names, cmp = diff_names)

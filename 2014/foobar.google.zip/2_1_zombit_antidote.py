def answer(meetings):
    mtngs_max = 0
    mtngs_len = len(meetings)
    meetings = sorted(meetings)

    for i in range(0, mtngs_len):
        [s, e] = meetings[i]
        mtngs = 1 # assume max meetings of length 1 for this iter
        
        for j in range(i + 1, mtngs_len):
            [s_n, e_n] = meetings[j] # new [s, e]

            if (s < e_n and e > s_n) or (e_n > s and s_n < e): continue # overlap

            [s, e] = meetings[j]

            mtngs += 1

        if mtngs > mtngs_max: mtngs_max = mtngs
    
    return mtngs_max

def answer(x):
    s = x
    while s > 10:
        x, s = s, 0
        while x > 0:
            s += x % 10
            x = x / 10

    return s

def get_lt_rels(words):
    rels = []
    l = len(words)

    for i in range(0, l):
        for j in range (i, l):
            w1, w2 = words[i], words[j]

            for k in range(0, min(len(w1), len(w2))):
                if w1[k] != w2[k] and not w1[k] + w2[k] in rels:
                    rels.append(w1[k] + w2[k])
                    break

    return rels

def calculate_ordering(rels, ret = ''):

    if rels == []:
        return ret

    rels_n = []

    for rel in rels:
        op1, op2 = rel[0], rel[1]

        if op2 in ret and not op1 in ret:
            i = ret.index(op2)
            ret = ret[:i] + op1 + ret[i:]
        elif op1 in ret and not op2 in ret:
            # since it's lt relation, move one to the right when using the other operand
            i = ret.index(op1) + 1
            ret = ret[:i] + op2 + ret[i:]
        elif op1 in ret and op2 in ret:
            ret = list(ret)
            ret[ret.index(op1)], ret[ret.index(op2)] = ret[ret.index(op2)], ret[ret.index(op1)]
            ret = ''.join(ret)
        elif ret == '': # this should be initial only
            ret += op1 + op2
        else:
            rels_n.append(rel)

    return calculate_ordering(rels_n, ret)

def answer(words):
    rels = get_lt_rels(words)
    print(rels)
    return calculate_ordering(rels)

if __name__ == '__main__':

    print(get_lt_rels(["asdfz", "ssdfe"]))
    print(get_lt_rels(["aaasdf", "zxcv"]))
#    print(calculate_ordering(["21", "32", "63"]) == "6321")
#    print(calculate_ordering(["63", "21", "32"]) == "6321")

#    print(answer(["z", "yx", "yz"]) == "xzy")
#    print(answer(["y", "z", "xy"]) == "yzx")
    print(answer(["ba", "ab", "cb"]) == "bac")
#    print(answer(["ab", "ac", "bc"]))

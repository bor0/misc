#include <stdio.h>
#include <stdlib.h>
#include "player.h"

int main(void) {
    int i = 0;
    struct game_obj *objects[3];

    objects[0] = player_init(100, 10, (struct position){1, 1}, "Boro", 10);
    objects[1] = enemy_init(10, 1, (struct position){2, 2}, "test 1", 30);
    objects[2] = enemy_init(10, 1, (struct position){3, 3}, "test 2", 30);

    printf("Hello World!");

    while (i<1000) {
        if (objects[i%3]->check_update(objects[i%3])) {
            objects[i%3]->update(objects[i%3]);
            i++;
            printf("update count: %d / 1000\n", i);
        }
    }

    for (i=0;i<3;i++) {
        free(objects[i]);
    }

    return 0;
}

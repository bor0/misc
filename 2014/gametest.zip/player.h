#ifndef PLAYER_H
#define PLAYER_H
#include <time.h>

struct position {
    int x;
    int y;
};

struct game_obj {
    struct position pos;
    int hp;
    int dps;
    char obj_name[16];
    char name[64];
    void (*update)(void *);
    int (*check_update)(void *);
    clock_t _ticks;
    clock_t updateticks;
};

struct player {
    struct game_obj base;
    int some_number;
};

struct enemy {
    struct game_obj base;
};

void player_update(void *obj);
void enemy_update(void *obj);
struct game_obj* player_init(int hp, int dps, struct position pos, char *name, clock_t updateticks);
struct game_obj* enemy_init(int hp, int dps, struct position pos, char *name, clock_t updateticks);
int check_update(void *obj);
#endif

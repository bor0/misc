#include "player.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void player_update(void *obj) {
    struct player *p = (struct player*)obj;
    clock_t c = check_update(obj);

    if (!c) {
        return;
    } else p->base._ticks = c;

    p->some_number++;
    printf("%s move [%s] (%d)\n", p->base.obj_name, p->base.name, p->some_number);
}

void enemy_update(void *obj) {
    struct game_obj *e = (struct game_obj *)obj;
    clock_t c = check_update(obj);

    if (!c) {
        return;
    } else e->_ticks = c;

    printf("%s move [%s]\n", e->obj_name, e->name);
}

struct game_obj* player_init(int hp, int dps, struct position pos, char *name, clock_t updateticks) {
    struct player *p = malloc(sizeof(struct player));
    p->base.hp = hp;
    p->base.dps = dps;
    p->base.pos = pos;
    p->base.update = player_update;
    p->base.updateticks = updateticks;
    p->base.check_update = check_update;
    strcpy(p->base.obj_name, "PLAYER");
    strncpy(p->base.name, name, sizeof(p->base.name));
    return (struct game_obj *)p;
}

struct game_obj* enemy_init(int hp, int dps, struct position pos, char *name, clock_t updateticks) {
    struct enemy *e = malloc(sizeof(struct player));
    e->base.hp = hp;
    e->base.dps = dps;
    e->base.pos = pos;
    e->base.update = enemy_update;
    e->base.updateticks = updateticks;
    e->base.check_update = check_update;
    strcpy(e->base.obj_name, "ENEMY");
    strncpy(e->base.name, name, sizeof(e->base.name));
    return (struct game_obj *)e;
}

int check_update(void *obj) {
    struct game_obj *e = (struct game_obj *)obj;
    clock_t c = clock();

    if (c - e->_ticks < e->updateticks) { // enemy update every 1000 ticks
        return 0;
    }

    return c;
}

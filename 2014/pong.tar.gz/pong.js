// Boro Sitnikovski 06.04.2014
// playing around with easeljs

(function(window, document) {

    var stage, w, h;
    var ball = {}, player1 = {}, player2 = {};
    var KEYCODE_W = 87;
    var KEYCODE_S = 83;
    var KEYCODE_A = 65;
    var KEYCODE_D = 68;
    var KEYCODE_SPACE = 32;

    function createRect(x, y, w, h) {
        var obj = new createjs.Shape();
        obj.graphics.beginFill("red").drawRect(0, 0, w, h);
        obj.x = x; obj.y = y; obj.w = w; obj.h = h;
        return obj;
    }

    //allow for WASD and arrow control scheme
    function handleKeyDown(e) {
        //cross browser issues exist
        if (!e) { var e = window.event; }
        switch (e.keyCode) {
            case KEYCODE_W: player1.direction = -1; return false;
            case KEYCODE_S: player1.direction = 1; return false;
            case KEYCODE_A: player1.direction = -2; return false;
            case KEYCODE_D: player1.direction = 2; return false;
            case KEYCODE_SPACE: deinit(); init(); return false;
        }
    }

    function init() {
        stage = new createjs.Stage("demoCanvas");
        w = stage.canvas.width;
        h = stage.canvas.height;

        ball.obj = createRect((w - 10)/2, (h - 10)/2, 10, 10);
        ball.angle = randomIntFromInterval(0, 360);
        ball.speedX = 7;
        ball.speedY = 7;

        player1.obj = createRect(0, 0, 7, 70);
        player1.speed = 10;

        player2.obj = createRect(w - 7, 0, 7, 70);
        player2.speed = 10;

        stage.addChild(ball.obj);
        stage.addChild(player1.obj);
        stage.addChild(player2.obj);

        stage.update();

        createjs.Ticker.addEventListener("tick", tick);
    }

    function deinit() {
        createjs.Ticker.removeEventListener("tick", tick);
    }

    function updatePlayerDirection(player) {
        if (player.direction == 1 || player.direction == -1) {
            target = player.obj.y + player.speed * player.direction;
            if (target < h - player.obj.h && target > 0) player.obj.y = target;
            else if (player.direction == -1) player.obj.y = 0;
            else if (player.direction == 1) player.obj.y = h - player.obj.h;
            player.direction = 0;
        }
        else if (player.direction == 2 || player.direction == -2) {
            target = player.obj.x + player.speed * player.direction;
            if (target < w - player.obj.w && target > 0) player.obj.x = target;
            else if (player.direction == -2) player.obj.x = 0;
            else if (player.direction == 2) player.obj.x = w - player.obj.w;
            player.direction = 0;
        }
    }

    function randomIntFromInterval(min,max)
    {
        return Math.floor(Math.random()*(max-min+1)+min);
    }

    function handleBallBounce(ball) {
        ball.obj.x += Math.cos(ball.angle * (Math.PI/180)) * ball.speedX;
        ball.obj.y += -Math.sin(ball.angle * (Math.PI/180)) * ball.speedY;

        if (checkCollisionPlayerBall(player1, ball)) {
            ball.angle = randomIntFromInterval(270, 270 + 180);
        } else if (ball.obj.x <= 0) {
            deinit();
            alert("Player 2 wins");
        } else if (checkCollisionPlayerBall(player2, ball)) {
            ball.angle = randomIntFromInterval(-270, -270 + 180);
        } else if (ball.obj.x >= w - ball.obj.w) {
            deinit();
            alert("Player 1 wins");
        }
        else if (ball.obj.y < 0 || ball.obj.y > h - ball.obj.h) ball.angle = -ball.angle;
    }

    function checkCollisionPlayerBall(player, ball) {
        return !(
            ((player.obj.y + player.obj.h) < (ball.obj.y)) ||
            (player.obj.y > (ball.obj.y + ball.obj.h)) ||
            ((player.obj.x + player.obj.w) < ball.obj.x) ||
            (player.obj.x > (ball.obj.x + ball.obj.w))
        );
    }

    function tick() {
        updatePlayerDirection(player1);
        handleBallBounce(ball);
        player2.obj.y = ball.obj.y - player2.obj.h/2;
        stage.update();
    }

    window.init = init;
    document.onkeydown = handleKeyDown;
    alert("HI MEN\nYOU WONT BE ABLE TO WIN AGAINST THIS PONG CPU\nCONTROLS = WASD, Space to restart\nHAVE FUN");

})(window, document);

import Chip8.Cpu
import Chip8.Opcodes
import System.Environment
import System.Random
import System.Exit
import Control.Monad (when, unless)
import qualified Data.ByteString.Lazy as BS

main = do
    x <- getArgs
    if length x /= 1
        then putStrLn "Usage: chip8 <filename>"
        else do
            let file = head x
            contents <- BS.readFile file
            randGen <- newStdGen
            let cpu = cpuInit (take (4096 - 0x200) $ BS.unpack contents) randGen
            loop cpu
            where
            loop cpu = do
                x <- getLine
                when (x == "step") $ do
                    let next = nextInstruction cpu
                    print next
                    loop $ calcInstruction cpu next
                when (x == "display") $ print cpu
                when (x == "exit") exitSuccess
                loop cpu

module Chip8.Opcodes (calcInstruction, nextInstruction) where
import Data.Bits
import Data.Word
import Chip8.Cpu
import System.Random

replaceNth n newVal (x:xs)
    | n == 0 = newVal:xs
    | otherwise = x:replaceNth (n-1) newVal xs

nextInstruction :: Cpu -> Word16
nextInstruction Cpu { _PC = _PC, _memory = mem } =
    opcode
    where
    opcode = (fh `shiftL` 8) .|. fl
    fh = fromIntegral $ mem !! pc
    fl = fromIntegral $ mem !! (pc + 1)
    pc = fromIntegral $ _PC

step :: Cpu -> Cpu
step cpu@Cpu { _PC = _PC } = cpu { _PC = _PC + 2 }

calcInstruction :: Cpu -> Word16 -> Cpu
calcInstruction c opcode = step $ op c opcode
    where
    op = case opcode .&. 0xF000 of
        0x0000 -> case opcode .&. 0xF of
            0x0 -> op00E0
            0xE -> op00EE
            _ -> const
        0x1000 -> op1NNN
        0x2000 -> op2NNN
        0x3000 -> op3XKK
        0x4000 -> op4XKK
        0x5000 -> op5XKK
        0x6000 -> op6XKK
        0x7000 -> op7XKK
        0x8000 -> case opcode .&. 0xF of
            0x0 -> op8XY0
            0x1 -> op8XY1
            0x2 -> op8XY2
            0x3 -> op8XY3
            0x4 -> op8XY4
            0x5 -> op8XY5
            0x6 -> op8XY6
            0x7 -> op8XY7
            0xE -> op8XYE
            _ -> const
        0x9000 -> op9XY0
        0xA000 -> opANNN
        0xB000 -> opBNNN
        0xC000 -> opCXKK
        0xD000 -> opDXYN
        0xE000 -> case opcode .&. 0xFF of
            0x9E -> opEX9E
            0xA1 -> opEXA1
            _ -> const
        0xF000 -> case opcode .&. 0xFF of
            0x07 -> opFX07
            0x0A -> opFX0A
            0x15 -> opFX15
            0x18 -> opFX18
            0x1E -> opFX1E
            0x29 -> opFX29
            0x33 -> opFX33
            0x55 -> opFX55
            0x65 -> opFX65
            _ -> const
        _ -> const

-- | Clears the screen
op00E0 :: Cpu -> Word16 -> Cpu
op00E0 cpu _ =
    cpu { _display = replicate 2048 0 }

-- | Returns from a subroutine
op00EE :: Cpu -> Word16 -> Cpu
op00EE cpu@Cpu { _SP = _SP, _PC = _PC, _stack = _stack } _ =
    cpu { _SP = _SP - 1, _PC = fromIntegral $ _stack !! fromIntegral (_SP - 1) }

-- | Jumps to address NNN.
op1NNN :: Cpu -> Word16 -> Cpu
op1NNN cpu@Cpu { _PC = _PC } opcode =
    cpu { _PC = opcode .&. 0xFFF }

-- | Calls subroutine at NNN
op2NNN :: Cpu -> Word16 -> Cpu
op2NNN cpu@Cpu { _SP = _SP, _PC = _PC, _stack = _stack } opcode =
    cpu { _SP = _SP + 1, _stack = replaceNth _SP (fromIntegral _PC) _stack, _PC = opcode .&. 0xFFF }

-- | Skips the next instruction if VX equals NN.
op3XKK :: Cpu -> Word16 -> Cpu
op3XKK cpu@Cpu { _v = _v } opcode =
    if fromIntegral (_v !! operand1) == operand2
    then step cpu
    else cpu
    where
    operand1 = fromIntegral (opcode .&. 0xF00) `shiftR` 8
    operand2 = opcode .&. 0x00FF

-- | Skips the next instruction if VX doesn't equal NN.
op4XKK :: Cpu -> Word16 -> Cpu
op4XKK cpu@Cpu { _v = _v } opcode =
    if fromIntegral (_v !! operand1) /= operand2
    then step cpu
    else cpu
    where
    operand1 = fromIntegral (opcode .&. 0xF00) `shiftR` 8
    operand2 = opcode .&. 0x00FF

-- | Skips the next instruction if VX equals VY.
op5XKK :: Cpu -> Word16 -> Cpu
op5XKK cpu@Cpu { _v = _v } opcode =
    if fromIntegral (_v !! operand1) == (_v !! operand2)
    then step cpu
    else cpu
    where
    operand1 = fromIntegral (opcode .&. 0xF00) `shiftR` 8
    operand2 = fromIntegral (opcode .&. 0xF0) `shiftR` 4

-- | Sets VX to NN.
op6XKK :: Cpu -> Word16 -> Cpu
op6XKK cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth operand1 operand2 _v }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = fromIntegral (opcode .&. 0xFF)

-- | Adds NN to VX.
op7XKK :: Cpu -> Word16 -> Cpu
op7XKK cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth operand1 operand2 _v }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = (_v !! fromIntegral operand1) + fromIntegral (opcode .&. 0xFF)

-- | Sets VX to the value of VY.
op8XY0 :: Cpu -> Word16 -> Cpu
op8XY0 cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth operand1 operand2 _v }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = fromIntegral (opcode .&. 0xF0) `shiftR` 4

-- | Sets VX to VX or VY.
op8XY1 :: Cpu -> Word16 -> Cpu
op8XY1 cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth operand1 operand2 _v }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = (_v !! fromIntegral operand1) .|. (fromIntegral (opcode .&. 0xF0) `shiftR` 4)

-- | Sets VX to VX and VY.
op8XY2 :: Cpu -> Word16 -> Cpu
op8XY2 cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth operand1 operand2 _v }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = (_v !! fromIntegral operand1) .&. (fromIntegral (opcode .&. 0xF0) `shiftR` 4)

-- | Sets VX to VX xor VY.
op8XY3 :: Cpu -> Word16 -> Cpu
op8XY3 cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth operand1 operand2 _v }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = (_v !! fromIntegral operand1) `xor` (fromIntegral (opcode .&. 0xF0) `shiftR` 4)

-- | Adds VY to VX. VF is set to 1 when there's a carry, and to 0 when there isn't. */
op8XY4 :: Cpu -> Word16 -> Cpu
op8XY4 cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth 15 carry _v' }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = (opcode .&. 0xF0) `shiftR` 4
    vx = _v !! fromIntegral operand1
    vy = _v !! fromIntegral operand2
    _v' = replaceNth operand1 (vx + vy) _v
    carry = if vx + vy > 0xFF then 1 else 0

-- | VY is subtracted from VX. VF is set to 0 when there's a borrow, and 1 when there isn't.
op8XY5 :: Cpu -> Word16 -> Cpu
op8XY5 cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth 15 borrow _v' }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = (opcode .&. 0xF0) `shiftR` 4
    vx = _v !! fromIntegral operand1
    vy = _v !! fromIntegral operand2
    _v' = replaceNth operand1 (vx - vy) _v
    borrow = if vx - vy > 0 then 1 else 0

-- | Shifts VX right by one. VF is set to the value of the least significant bit of VX before the shift.
op8XY6 :: Cpu -> Word16 -> Cpu
op8XY6 cpu@Cpu { _v = _v } opcode = 
    cpu { _v = _v'' }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    lsb = (_v !! fromIntegral operand1) .&. 1
    _v' = replaceNth 15 lsb _v
    _v'' = replaceNth operand1 ((_v' !! fromIntegral operand1) `shiftR` 1) _v'

-- | Sets VX to VY minus VX. VF is set to 0 when there's a borrow, and 1 when there isn't.
op8XY7 :: Cpu -> Word16 -> Cpu
op8XY7 cpu@Cpu { _v = _v } opcode =
    cpu { _v = replaceNth 15 borrow _v' }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    operand2 = (opcode .&. 0xF0) `shiftR` 4
    vx = _v !! fromIntegral operand1
    vy = _v !! fromIntegral operand2
    _v' = replaceNth operand1 (vy - vx) _v
    borrow = if vy - vx > 0 then 1 else 0

-- | Shifts VX left by one. VF is set to the value of the most significant bit of VX before the shift.
op8XYE :: Cpu -> Word16 -> Cpu
op8XYE cpu@Cpu { _v = _v } opcode = 
    cpu { _v = _v'' }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    msb = (_v !! fromIntegral operand1 `shiftR` 7) .&. 0x80
    _v' = replaceNth 15 msb _v
    _v'' = replaceNth operand1 ((_v' !! fromIntegral operand1) `shiftL` 1) _v'

-- | Skips the next instruction if VX equals VY.
op9XY0 :: Cpu -> Word16 -> Cpu
op9XY0 cpu@Cpu { _v = _v } opcode =
    if fromIntegral (_v !! operand1) /= (_v !! operand2)
    then step cpu
    else cpu
    where
    operand1 = fromIntegral (opcode .&. 0xF00) `shiftR` 8
    operand2 = fromIntegral (opcode .&. 0xF0) `shiftR` 4

-- | Sets I to the address NNN.
opANNN :: Cpu -> Word16 -> Cpu
opANNN cpu@Cpu { _I = _I } opcode =
    cpu { _I = operand1 }
    where
    operand1 = fromIntegral (opcode .&. 0xFFF)

-- | Jumps to the address NNN plus V0
opBNNN :: Cpu -> Word16 -> Cpu
opBNNN cpu@Cpu { _PC = _PC, _v = _v } opcode =
    cpu { _PC = operand1 + fromIntegral (head _v) }
    where
    operand1 = fromIntegral (opcode .&. 0xFFF)

-- | Sets VX to a random number and NN.
opCXKK :: Cpu -> Word16 -> Cpu
opCXKK cpu@Cpu { _v = _v, _randgen = _randgen } opcode =
    cpu { _v = replaceNth operand1 (r .&. fromIntegral (opcode .&. 0xF)) _v, _randgen = _randgen' }
    where
    operand1 = (opcode .&. 0xF00) `shiftR` 8
    (r, _randgen') = randomR (0x0, 0xFF) _randgen

-- | Sprites stored in CPU at location in index register (I), maximum 8bits wide.
-- | Wraps around the screen. If when drawn, clears a pixel, register VF is set to 1
-- | otherwise it is zero. All drawing is XOR drawing (e.g. it toggles the screen pixels)
opDXYN :: Cpu -> Word16 -> Cpu
opDXYN = const -- undefined

-- | Skips the next instruction if the key stored in VX is pressed.
opEX9E :: Cpu -> Word16 -> Cpu
opEX9E cpu@Cpu { _v = _v, _key = _key } opcode =
    if fromIntegral (_key !! operand1) /= 0
    then step cpu
    else cpu
    where
    operand1 = fromIntegral (opcode .&. 0x0F00) `shiftR` 8

-- | Skips the next instruction if the key stored in VX isn't pressed.
opEXA1 :: Cpu -> Word16 -> Cpu
opEXA1 cpu@Cpu { _v = _v, _key = _key } opcode =
    if fromIntegral (_key !! operand1) == 0
    then step cpu
    else cpu
    where
    operand1 = fromIntegral (opcode .&. 0x0F00) `shiftR` 8

-- | Sets VX to the value of the delay timer.
opFX07 :: Cpu -> Word16 -> Cpu
opFX07 cpu@Cpu { _delayTimer = _delayTimer, _v = _v } opcode =
    cpu { _v = replaceNth operand1 _delayTimer _v }
    where
    operand1 = (opcode .&. 0x0F00) `shiftR` 8

-- | A key press is awaited, and then stored in VX.
opFX0A :: Cpu -> Word16 -> Cpu
opFX0A cpu@Cpu { _PC = _PC, _v = _v, _key = _key } opcode =
    go _v'
    where
    operand1 = (opcode .&. 0x0F00) `shiftR` 8
    _v' = foldr foldingFunction (_v, 0, False) _key
    foldingFunction a (b, c, d) = if a /= 0 then (replaceNth operand1 c b, c+1, True) else (b, c+1, d)
    go (_v, _, True) = cpu { _v = _v }
    go (_v, _, False) = cpu { _PC = _PC - 2, _v = _v }

-- | Sets the delay timer to VX.
opFX15 :: Cpu -> Word16 -> Cpu
opFX15 cpu@Cpu { _delayTimer = _delayTimer, _v = _v } opcode = 
    cpu { _delayTimer = _v !! operand1 }
    where
    operand1 = fromIntegral (opcode .&. 0x0F00) `shiftR` 8

-- | Sets the sound timer to VX.
opFX18 :: Cpu -> Word16 -> Cpu
opFX18 cpu@Cpu { _soundTimer = _soundTimer, _v = _v } opcode = 
    cpu { _soundTimer = _v !! operand1 }
    where
    operand1 = fromIntegral (opcode .&. 0x0F00) `shiftR` 8

-- | Adds VX to I
opFX1E :: Cpu -> Word16 -> Cpu
opFX1E cpu@Cpu { _I = _I, _v = _v } opcode = 
    cpu { _I = _I', _v = _v' }
    where
    operand1 = fromIntegral (opcode .&. 0x0F00) `shiftR` 8
    _I' = fromIntegral (_v !! operand1) + _I
    _v' = replaceNth 15 (if _I' > 0xFFF then 1 else 0) _v

-- | Sets I to the location of the sprite for the character in VX. Characters 0-F (in hexadecimal) are represented by a 4x5 font.
opFX29 :: Cpu -> Word16 -> Cpu
opFX29 cpu@Cpu { _I = _I, _v = _v } opcode =
    cpu { _I = fromIntegral (_v !! operand1) * 5 }
    where
    operand1 = fromIntegral (opcode .&. 0x0F00) `shiftR` 8

-- | Stores the Binary-coded decimal representation of VX, with the most significant
-- | of three digits at the address in I, the middle digit at I plus 1, and the least
-- | significant digit at I plus 2. (In other words, take the decimal representation of VX,
-- | place the hundreds digit in CPU at location in I, the tens digit at location I+1,
-- | and the ones digit at location I+2.)
opFX33 :: Cpu -> Word16 -> Cpu
opFX33 cpu@Cpu { _I = _I, _v = _v, _memory = _memory } opcode =
    cpu { _memory = _memory''' }
    where
    operand1 = fromIntegral (opcode .&. 0x0F00) `shiftR` 8
    vx = _v !! operand1
    _memory' = replaceNth _I ((vx `div` 100) `mod` 10) _memory
    _memory'' = replaceNth _I ((vx `div` 10) `mod` 10) _memory'
    _memory''' = replaceNth _I (vx `mod` 10) _memory''

-- | Stores V0 to VX in CPU starting at address I.
opFX55 :: Cpu -> Word16 -> Cpu
opFX55 cpu@Cpu { _I = _I, _v = _v, _memory = _memory } opcode =
    cpu { _memory = _memory', _I = _I' }
    where
    operand1 = (opcode .&. 0x0F00) `shiftR` 8
    (_memory', _) = foldr foldingFunction (_memory, operand1) _v
    foldingFunction a (b, c) = (replaceNth (_I + c) a b, c-1) 
    _I' = _I + operand1

-- | Fills V0 to VX with values from CPU starting at address I.
opFX65 :: Cpu -> Word16 -> Cpu
opFX65 cpu@Cpu { _I = _I, _v = _v, _memory = _memory } opcode =
    cpu { _v = _v', _I = _I' }
    where
    operand1 = (opcode .&. 0x0F00) `shiftR` 8
    (_v', _) = foldr foldingFunction (_v, operand1) _memory
    foldingFunction a (b, c) = (replaceNth (_I + c) a b, c-1) 
    _I' = _I + operand1

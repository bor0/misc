#include "queue.h"

extern struct tree tree_root;

void traverse() {
    struct tree *val = &tree_root;
    queue_push(val);
    while (!queue_empty()) {
        val = queue_pop();
        printf("%d\n", val->val);
        if (val->left != NULL) queue_push(val->left);
        if (val->right != NULL) queue_push(val->right);
    }
}

int main() {
    buildtree();
    traverse();
    return 0;
}

#include "stack.h"

extern struct tree tree_root;

void traverse() {
    struct tree *val = &tree_root;
    stack_push(val);
    while (!stack_empty()) {
        val = stack_pop();
        printf("%d\n", val->val);
        if (val->right != NULL) stack_push(val->right);
        if (val->left != NULL) stack_push(val->left);
    }
}

void traverse2(struct tree *root) {
    if (root == NULL) return;
    printf("%d\n", root->val);
    traverse2(root->left);
    traverse2(root->right);
}

int main() {
    buildtree();
    traverse();
    return 0;
}

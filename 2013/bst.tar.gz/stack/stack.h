#include <malloc.h>
#include "tree.h"

struct stack {
    struct stack *next;
    struct tree *val;
};

struct tree *stack_pop();
int stack_empty();
void stack_print();
void stack_push(struct tree *);

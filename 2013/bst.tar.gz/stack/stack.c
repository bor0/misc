#include "stack.h"

struct stack *stack_top = NULL;

struct tree *stack_pop() {
    struct tree *tr = NULL;
    struct stack *tmp = stack_top;

    if (!stack_empty()) {
        stack_top = stack_top->next;
        tr = tmp->val;
        free(tmp);
    }

    //if (tr != NULL) printf("popped %d\n", tr->val);

    return tr;
}

int stack_empty() {
    return (stack_top == NULL) ? 1 : 0;
}

void stack_print() {
    struct stack *tmp = stack_top;
    while (tmp != NULL) {
        printf("%p [%p]; ", tmp, tmp->val);
        tmp = tmp->next;
    }
    putchar('\n');
}

void stack_push(struct tree *val) {
    if (val == NULL) return;
    if (stack_empty()) {
        stack_top = (struct stack *)malloc(sizeof(struct stack));
        stack_top->next = NULL;
        stack_top->val = val;
    } else {
        struct stack *tmp = (struct stack *)malloc(sizeof(struct stack));
        tmp->next = stack_top;
        tmp->val = val;
        stack_top = tmp;
    }
    //printf("ok, pushed %d\n", val->val);
}

#include <malloc.h>
#include "tree.h"

struct queue {
    struct queue *next;
    struct tree *val;
};

struct tree *queue_pop();
int queue_empty();
void queue_print();
void queue_push(struct tree *);

#include "queue.h"

struct queue *queue_top = NULL;

struct tree *queue_pop() {
    struct tree *tr = NULL;
    struct queue *tmp = queue_top;

    if (!queue_empty()) {
        queue_top = queue_top->next;
        tr = tmp->val;
        free(tmp);
    }

    //if (tr != NULL) printf("popped %d\n", tr->val);

    return tr;
}

int queue_empty() {
    return (queue_top == NULL) ? 1 : 0;
}

void queue_print() {
    struct queue *tmp = queue_top;
    while (tmp != NULL) {
        printf("%p [%p]; ", tmp, tmp->val);
        tmp = tmp->next;
    }
    putchar('\n');
}

void queue_push(struct tree *val) {
    if (val == NULL) return;
    if (queue_empty()) {
        queue_top = (struct queue *)malloc(sizeof(struct queue));
        queue_top->next = NULL;
        queue_top->val = val;
    } else {
        struct queue *tmp = (struct queue *)malloc(sizeof(struct queue));
        tmp->next = NULL;
        tmp->val = val;
        struct queue *top = queue_top;
        while (top->next != NULL) top = top->next;
        top->next = tmp;
    }
    //printf("ok, pushed %d\n", val->val);
}

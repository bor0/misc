#include "tree.h"

struct tree tree_root;

void buildtree() {
    static struct tree child1left, child1right;
    static struct tree child21left, child21right, child22left, child22right;

    tree_root.val = 1;
    tree_root.left = &child1left;
    tree_root.right = &child1right;

    child1left.val = 2;
    child1left.left = &child21left;
    child1left.right = &child21right;
    child21left.left = NULL;
    child21left.right = NULL;
    child21right.left = NULL;
    child21right.right = NULL;
    child21left.val = 4;
    child21right.val = 5;

    child1right.val = 3;
    child1right.left = &child22left;
    child1right.right = &child22right;
    child22left.left = NULL;
    child22left.right = NULL;
    child22right.left = NULL;
    child22right.right = NULL;
    child22left.val = 6;
    child22right.val = 7;

}

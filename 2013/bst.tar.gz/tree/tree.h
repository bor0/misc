#include <stdio.h>

struct tree {
    struct tree *left;
    struct tree *right;
    int val;
};

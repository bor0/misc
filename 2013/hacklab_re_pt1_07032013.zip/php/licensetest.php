<?php
if (!isset($_GET['usercode']) || !isset($_GET['time'])) {
	echo "Insufficient parameters";
}
else if ($_GET['usercode'] != 1337) {
	echo "Invalid user code";
} else {
	$curtime = strtotime($_GET['time']);
	$maxtime = strtotime("01.02.2013");
	if ($curtime > $maxtime) echo 'false';
	else echo 'true';
}
#include <windows.h>
#include "libcurl/include/curl/curl.h"

libcurl_function_pt(void *ptr, size_t size, size_t nmemb, void *stream) {
	if (lstrcmp(ptr, "true") == 0) {
		MessageBoxA(0, "Congratulations!  Access granted.", "BoR0's crackme - Server reply", MB_ICONINFORMATION);
	} else if (lstrcmp(ptr, "false") == 0) {
		MessageBoxA(0, "ERROR!  Program is expired for current user.", "BoR0's crackme - Server reply", MB_ICONERROR);
	} else {
		MessageBoxA(0, ptr, "BoR0's crackme - Server reply", MB_ICONERROR);
	}
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd) {
	char http[512];
	SYSTEMTIME StandardDate;
	CURL *curl;
	GetLocalTime(&StandardDate);

	wsprintfA(http, "http://bor0.users.sourceforge.net/licensetest.php?usercode=1337&time=%02d.%02d.%4d", StandardDate.wDay, StandardDate.wMonth, StandardDate.wYear);

	MessageBoxA(0, "Press OK to contact server and check dates..", "BoR0's crackme", MB_ICONASTERISK);

	curl = curl_easy_init();

	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, http);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, libcurl_function_pt);

		curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	ExitProcess(0);

}
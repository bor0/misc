#include <stdio.h>

void plugin_register() {
    printf("plugin 2 here\n");
}

#include <stdio.h>
#include <dlfcn.h>

char buffer[512] = "./";

int main() {
    void *handle;
    typedef void (*plugin_register)();
    const char *dlsym_error;

    printf("Provide plugin name (e.g. plugin1.so): ");
    scanf("%s", buffer+2);

    handle = dlopen(buffer, RTLD_LAZY);

    if (!handle) {
        printf("Cannot open plugin\n");
        return 1;
    }

    dlerror();

    plugin_register plugin_init = (plugin_register) dlsym(handle, "plugin_register");

    dlsym_error = dlerror();

    if (dlsym_error) {
        printf("Cannot load symbol 'plugin_register'\n");
        dlclose(handle);
        return 1;
    }

    plugin_init();

    dlclose(handle);

    return 0;
}

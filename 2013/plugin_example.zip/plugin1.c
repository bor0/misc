#include <stdio.h>

void plugin_register() {
    printf("plugin 1 here\n");
}
